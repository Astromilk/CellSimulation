Result viewer of subcellular element modeling of inner cell mass

Background
This code visualizes the three dimensional results of subcellular element (SCE) simulation.

Configuration
The model was developed with Javascript code. An open-source library (visualization toolkit for Javascript, vtk.js@26.1.0, npm install @kitware/vtk.js)was used. The program can work in Edge and Chrome, but not in IE browser. 

Running
1. Make sure "CellViewer.html" and "main.js" are in the same path.
2. Run "CellViewer.html", 
    Upload cell property, choose "CellPropXXX.csv",
    Upload cell motion, choose "CellMotionXXX.csv",
    Hit "Play" to display the three dimensional motion of the cell model,
    Drag slider to show a specific frame of the process.
