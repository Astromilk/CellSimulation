#ifndef EMBRY_20221015
#define EMBRY_20221015

#include"SCE.h"
#include "Cl.h"
#include <string>
#include <vector>

using std::string;

class CEmbry //Class of Embryo
{
//Static variable and functions
public:
	//Set the SCE list for the Embryo class
	static bool StSCEAry(std::vector<CSCE>* pSCEAry);
	//Get the SCE list of class
	static std::vector<CSCE>* GtSCEAry() { return m_pSCEAry; }
	//Return embryo diameter at time fT, including contraction and expansion
	static double Dmtr_(const double& fT);
	//Return embryo diameter at time fT, including contraction, expansion, and hold
	static double Dmtr_AdHld(const double& fT);
	//Access m_fTShrnk, the duration of one contraction
	static double& TShrnk() { return m_fTShrnk; }
	//Access m_fTExpnd, the duration of one expansion
	static double& TExpnd() { return m_fTExpnd; }
	//Access m_fTHld, the interval time between two cycles
	static double& THld() { return m_fTHld; }
	//Access m_bTE, if ICM is isolated from blastocyst
	static bool& TE() { return m_bTE; }
	//Access m_bOsclt, if blastocyst oscilation.
	static bool& Osclt() { return m_bOsclt; }

private:
	static std::vector<CSCE>* m_pSCEAry;
	static double m_fTShrnk; //the duration of one contraction
	static double m_fTExpnd; //the duration of one expansion
	static double m_fTHld; //the interval time between two cycles
	static double m_fTPrpr; //Reference time for initial condition development
	static bool m_bTE; //if ICM is isolated from blastocyst
	static bool m_bOsclt; //if blastocyst oscilation.

//��Static
public:	
	//Construction
	CEmbry();
	//Destruction
	~CEmbry() {;}
	//Add a cell in embryo and add corresponding SCEs into SCE list. Input damping, type (pEPI of pPrE), SCE amount per cell, center coordinate at beginning
	bool AdCl(const double& fC, const int& iTyp, const double& fDmtr, const int& iSCEAmntInCl, const double& fX0, const double& fY0, const double& fZ0);
	//Intial cell arrays with the EPI and PrE distributed uniformly. 
	bool Intl(const int& iXAmnt, const int& iYAmnt, const int& iZAmnt);
	//Intial Embryo from files: SCE propery, SCE Motion, at a certain frame, default is seting is import models from the last frame of the file
	bool Intl(const string& sPthSCEPrp, const string& sPthSCEMtn, const double& iFrm = -1);
	//Set Time. The time poins in the time list will be exported.
	bool StT(const double& fTBgn, const double& fTEnd);
	//Access m_aCl, the list of cells
	std::vector<CCl>& aCl(void) { return m_aCl; }
	//Export SCE properties
	bool ExprtSCEPrp(const string& sPth);
	//Export SCE motion. 
	bool ExprtSCEMtn(const string& sPth);
	//Export Cell properties
	bool ExprtClPrp(const string& sPth, const int& iLngAmnt, const int& iLtAmnt);
	//Export Cell motion
	bool ExprtClMtn(const string& sPth, const int& iLngAmnt, const int& iLtAmnt);
	//Export Cell motion
	bool ExprtClVlcty(const string& sPth);
	//Export sort index
	bool ExprtSrtIndx(const string& sPth);
	//Show sort index
	bool ShwSrtIndx();
	//Get Sort index at a frame
	double SrtIndx(const int& iInsdTyr, const long& iFrm);
	//Calculate cell morphology index
	bool Mrphlgy();
	//Export Cell distacne & contact (SCE amount contacted)
	bool ExprtClRltn(const string& sPthDstnc, const string& sPthCntct, const long& iFrm);
	//Return Cell contace SCE amouunt
	double CntctSCE(const int& iClA, const int& iClB, const long& iFrm);
	
private:
	std::vector<CCl> m_aCl; // List of Cells
	
};

//Split a string into substring lists
std::vector<string> Split(string sDt, char cDvd);

#endif

