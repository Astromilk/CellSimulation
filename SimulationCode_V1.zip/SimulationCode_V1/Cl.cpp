#include "Cl.h"
#include <pcl\point_cloud.h>
#include <pcl\kdtree\kdtree_flann.h>

std::vector<CSCE>* CCl::m_pSCEAry;

bool CCl::StSCEAry(std::vector<CSCE>* pSCEAry)
{
	m_pSCEAry = pSCEAry;
	return true;
}

CCl::CCl(const double& fDmtr, const long& iSCEHd, const long& iSCETl)
{
	m_fDmtr = fDmtr;
	m_iSCEHd = iSCEHd;
	m_iSCETl = iSCETl;
}

double CCl::GtSrfcVrtx(std::vector<std::vector<double>>& aVrtx, const long& iFrm, const int& iLngAmnt, const int& iLtAmnt)
{
	//////Safe
	//////Varialbe define
	aVrtx.clear();
	std::vector<CSCE>& aSCE = *m_pSCEAry;
	long iSCEAmntInCl = m_iSCETl - m_iSCEHd + 1;
	double aCntr[3]={0.0,0.0,0.0};
	double fLngRdsIncr = 3.14 / ((double)(iLngAmnt - 1)); //radian increment in longitude line
	double fLtRdsIncr = 6.28 / ((double)iLtAmnt); //radian increment in latitude line
	//PCL point cloud and KT tree, search nearest points
	pcl::PointCloud<pcl::PointXYZ>::Ptr pCld(new pcl::PointCloud<pcl::PointXYZ>);
	pcl::KdTreeFLANN<pcl::PointXYZ> KdTr;
	double fShpIndx(0.0);
	//////Process
	//Center
	for (long iS = m_iSCEHd; iS <= m_iSCETl; ++iS)
	{
		aCntr[0] += aSCE[iS].aP()[iFrm][0];
		aCntr[1] += aSCE[iS].aP()[iFrm][1];
		aCntr[2] += aSCE[iS].aP()[iFrm][2];
	}
	aCntr[0] = aCntr[0] / ((double)iSCEAmntInCl);
	aCntr[1] = aCntr[1] / ((double)iSCEAmntInCl);
	aCntr[2] = aCntr[2] / ((double)iSCEAmntInCl);

	//Surface vertex before iterate
	{
		vector<double> vVrtx(3);
		//South pole		
		vVrtx[0] = aCntr[0]; vVrtx[1] = aCntr[1]; vVrtx[2] = aCntr[2] - 2.0*m_fDmtr;
		aVrtx.push_back(vVrtx);
		//
		for (int iLng = 1; iLng < (iLngAmnt - 1); ++iLng)
		{
			double fSbD = 2.0*m_fDmtr * cos(-1.57 + fLngRdsIncr * ((double)iLng));
			for (int iLt = 0; iLt < iLtAmnt; ++iLt)
			{
				vVrtx[0] = aCntr[0] + fSbD * cos(fLtRdsIncr * ((double)iLt));
				vVrtx[1] = aCntr[1] + fSbD * sin(fLtRdsIncr * ((double)iLt));
				vVrtx[2] = aCntr[2] + 2.0*m_fDmtr * sin(-1.57 + fLngRdsIncr * ((double)iLng));
				aVrtx.push_back(vVrtx);
			}
		}
		//North pole
		vVrtx[0] = aCntr[0]; vVrtx[1] = aCntr[1]; vVrtx[2] = aCntr[2] + 2.0*m_fDmtr;
		aVrtx.push_back(vVrtx);
	}
	
	//develop cell surface 
	pCld->width = iSCEAmntInCl;
	pCld->height = 1;
	pCld->resize(pCld->width * pCld->height);
	for (long iS = 0; iS < iSCEAmntInCl; ++iS)
	{
		pCld->points[iS].x = aSCE[iS+m_iSCEHd].aP()[iFrm][0];
		pCld->points[iS].y = aSCE[iS+m_iSCEHd].aP()[iFrm][1];
		pCld->points[iS].z = aSCE[iS+m_iSCEHd].aP()[iFrm][2];
	}
	KdTr.setInputCloud(pCld);
	//iterate 1
	for (int iV = 0; iV < aVrtx.size(); ++iV)
	{
		vector<double>& vVrtx = aVrtx[iV];
		//KD Tree
		pcl::PointXYZ PntCntr;
		int iK = 3;
		pcl::Indices IndxNr;
		std::vector<float> vRdsNr;
		PntCntr.x = vVrtx[0];
		PntCntr.y = vVrtx[1];
		PntCntr.z = vVrtx[2];
		KdTr.nearestKSearch(PntCntr, iK, IndxNr, vRdsNr);
		double aOrnt[3] = { vVrtx[0]-aCntr[0], vVrtx[1]-aCntr[1], vVrtx[2]-aCntr[2] };
		double fOrntNrm = sqrt(aOrnt[0]*aOrnt[0]+aOrnt[1]*aOrnt[1]+aOrnt[2]*aOrnt[2]);
		aOrnt[0] = aOrnt[0]/fOrntNrm; aOrnt[1] = aOrnt[1]/fOrntNrm; aOrnt[2] = aOrnt[2]/fOrntNrm; //normilization
		double aNr[3]={0.0,0.0,0.0};
		for (int iNr = 0; iNr < IndxNr.size(); ++iNr)
		{
			int jS = IndxNr[iNr];
			aNr[0] += pCld->points[jS].x;
			aNr[1] += pCld->points[jS].y;
			aNr[2] += pCld->points[jS].z;
		}
		double fFctrLn = CSCE::REq()/1.732 + ((aNr[0] - 3.0 * aCntr[0]) * aOrnt[0] + (aNr[1] - 3.0 * aCntr[1]) * aOrnt[1] + (aNr[2] - 3.0 * aCntr[2]) * aOrnt[2]) / 3.0;
		vVrtx[0] = aCntr[0] + fFctrLn*aOrnt[0];
		vVrtx[1] = aCntr[1] + fFctrLn*aOrnt[1];
		vVrtx[2] = aCntr[2] + fFctrLn*aOrnt[2];
	}
	//Iterate 2
	for (int iV = 0; iV < aVrtx.size(); ++iV)
	{
		vector<double>& vVrtx = aVrtx[iV];
		//KD Tree
		pcl::PointXYZ PntCntr;
		int iK = 3;
		pcl::Indices IndxNr;
		std::vector<float> vRdsNr; 
		PntCntr.x = vVrtx[0];
		PntCntr.y = vVrtx[1];
		PntCntr.z = vVrtx[2];
		KdTr.nearestKSearch(PntCntr, iK, IndxNr, vRdsNr);
		double aOrnt[3] = { vVrtx[0] - aCntr[0], vVrtx[1] - aCntr[1], vVrtx[2] - aCntr[2] };
		double fOrntNrm = sqrt(aOrnt[0] * aOrnt[0] + aOrnt[1] * aOrnt[1] + aOrnt[2] * aOrnt[2]);
		aOrnt[0] = aOrnt[0] / fOrntNrm; aOrnt[1] = aOrnt[1] / fOrntNrm; aOrnt[2] = aOrnt[2] / fOrntNrm;
		double aNr[3] = { 0.0,0.0,0.0 };
		for (int iNr = 0; iNr < IndxNr.size(); ++iNr)
		{
			int jS = IndxNr[iNr];
			aNr[0] += pCld->points[jS].x;
			aNr[1] += pCld->points[jS].y;
			aNr[2] += pCld->points[jS].z;
		}
		double fFctrLn = CSCE::REq()/1.732 + ((aNr[0] - 3.0 * aCntr[0]) * aOrnt[0] + (aNr[1] - 3.0 * aCntr[1]) * aOrnt[1] + (aNr[2] - 3.0 * aCntr[2]) * aOrnt[2]) / 3.0;
		vVrtx[0] = aCntr[0] + fFctrLn * aOrnt[0];
		vVrtx[1] = aCntr[1] + fFctrLn * aOrnt[1];
		vVrtx[2] = aCntr[2] + fFctrLn * aOrnt[2];
	}

	//Shape index 2D,
	if (true)
	{
		double fPrmtrZ(0.0), fPrmtrY(0.0), fPrmtrX(0.0);
		double fArZ(0.0), fArY(0.0), fArX(0.0);
		int iEqtrBgn = ((iLngAmnt - 3) / 2) * iLtAmnt + 1; 
		int iEqtrEnd = ((iLngAmnt - 1) / 2) * iLtAmnt;
		//Z, shape index at equator
		for (int iV = iEqtrBgn; iV < iEqtrEnd; ++iV)
		{
			fPrmtrZ += sqrt(pow(aVrtx[iV][0] - aVrtx[iV+1][0], 2) + pow(aVrtx[iV][1] - aVrtx[iV+1][1], 2) + pow(aVrtx[iV][2] - aVrtx[iV+1][2], 2));
			fArZ += 0.5 * sin(fLtRdsIncr) * sqrt(pow(aVrtx[iV][0] - aCntr[0], 2) + pow(aVrtx[iV][1] - aCntr[1], 2) + pow(aVrtx[iV][2] - aCntr[2], 2)) * sqrt(pow(aVrtx[iV + 1][0] - aCntr[0], 2) + pow(aVrtx[iV + 1][1] - aCntr[1], 2) + pow(aVrtx[iV + 1][2] - aCntr[2], 2));
		}
		fPrmtrZ += sqrt(pow(aVrtx[iEqtrEnd][0] - aVrtx[iEqtrBgn][0], 2) + pow(aVrtx[iEqtrEnd][1] - aVrtx[iEqtrBgn][1], 2) + pow(aVrtx[iEqtrEnd][2] - aVrtx[iEqtrBgn][2], 2));
		fArZ += 0.5 * sin(fLtRdsIncr) * sqrt(pow(aVrtx[iEqtrEnd][0] - aCntr[0], 2) + pow(aVrtx[iEqtrEnd][1] - aCntr[1], 2) + pow(aVrtx[iEqtrEnd][2] - aCntr[2], 2)) * sqrt(pow(aVrtx[iEqtrBgn][0] - aCntr[0], 2) + pow(aVrtx[iEqtrBgn][1] - aCntr[1], 2) + pow(aVrtx[iEqtrBgn][2] - aCntr[2], 2));
		//Y & X plane Shape index
		{
			//Y: 0->1
			int iA(0), iB(1);
			fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArY += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
			//Y: 0->1+iLtAmnt/2
			iB = 1+iLtAmnt/2;
			fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArY += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
			//X: 0->1+iLtAmnt/4
			iB = 1+iLtAmnt/4;
			fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArX += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
			//X: 0->1+3*iLtAmnt/4
			iB = 1+3*iLtAmnt/4;
			fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArX += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
			//
			for (int iLng = 0; iLng <= (iLngAmnt - 4); ++iLng)
			{
				//Y: iLng * iLtAmnt + 1 -> (iLng+1) * iLtAmnt + 1
				iA = iLng * iLtAmnt + 1; iB = (iLng+1) * iLtAmnt + 1;
				fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
				fArY += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
				//Y: iLng * iLtAmnt + 1 + iLtAmnt/2 -> (iLng+1) * iLtAmnt + 1 + iLtAmnt/2
				iA = iLng * iLtAmnt + 1 + iLtAmnt/2; iB = (iLng+1) * iLtAmnt + 1 + iLtAmnt/2;
				fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
				fArY += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
				//X: iLng * iLtAmnt + 1 + iLtAmnt/4 -> (iLng+1) * iLtAmnt + 1 + iLtAmnt/4
				iA = iLng * iLtAmnt + 1 + iLtAmnt/4; iB = (iLng+1) * iLtAmnt + 1 + iLtAmnt/4;
				fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
				fArX += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
				//X: iLng * iLtAmnt + 1 + 3*iLtAmnt/4 -> (iLng+1) * iLtAmnt + 1 + 3*iLtAmnt/4
				iA = iLng * iLtAmnt + 1 + 3*iLtAmnt/4; iB = (iLng+1) * iLtAmnt + 1 + 3*iLtAmnt/4;
				fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
				fArX += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
			}
			//Y: (iLngAmnt-2)*iLtAmnt + 1 -> (iLngAmnt-3) * iLtAmnt + 1
			iA = (iLngAmnt-2)*iLtAmnt + 1; iB=(iLngAmnt-3) * iLtAmnt + 1;
			fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArY += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
			//Y: (iLngAmnt-2)*iLtAmnt + 1 -> (iLngAmnt-3) * iLtAmnt + 1 +iLtAmnt/2
			iB = (iLngAmnt-3) * iLtAmnt + 1 + iLtAmnt/2;
			fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArY += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
			//X: (iLngAmnt-2)*iLtAmnt + 1 -> (iLngAmnt-3) * iLtAmnt + 1 +iLtAmnt/4
			iB = (iLngAmnt-3) * iLtAmnt + 1 + iLtAmnt/4;
			fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArX += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
			//X: (iLngAmnt-2)*iLtAmnt + 1 -> (iLngAmnt-3) * iLtAmnt + 1 +3*iLtAmnt/4
			iB = (iLngAmnt-3) * iLtAmnt + 1 + 3*iLtAmnt/4;
			fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArX += 0.5*sin(fLngRdsIncr)*sqrt(pow(aVrtx[iA][0]-aCntr[0], 2) + pow(aVrtx[iA][1]-aCntr[1], 2) + pow(aVrtx[iA][2]-aCntr[2], 2))*sqrt(pow(aVrtx[iB][0]-aCntr[0], 2) + pow(aVrtx[iB][1]-aCntr[1], 2) + pow(aVrtx[iB][2]-aCntr[2], 2));
		}
		fShpIndx = (fPrmtrZ / sqrt(fArZ) + fPrmtrY / sqrt(fArY) + fPrmtrX / sqrt(fArX))/3.0;
		//std::cout<<"fPrmtrZ: "<< fPrmtrZ<<", fPrmtrY: "<<fPrmtrY<<", fPrmtrX: "<<fPrmtrX<<"\n";
		//std::cout << "fArZ: " << fArZ << ", fArY: " << fArY << ", fArX: " << fArX << "\n";
		//std::cout<<"fShpIndx: X = "<< fPrmtrX / sqrt(fArX)<<", Y = "<<fPrmtrY / sqrt(fArY)<<", Z = "<<fPrmtrZ / sqrt(fArZ)<<"\n";
	}
	/////Variable finish
	/////Normal end
	return fShpIndx;
}

double CCl::GtMrphlgy(std::vector<double>& vCntr, double& fAvrgRds, std::vector<std::vector<double>>& aVrtx, const long& iFrm, const int& iLngAmnt, const int& iLtAmnt)
{
	//////Safe
	vCntr.resize(3); vCntr[0] = vCntr[1] = vCntr[2] = 0.0;
	fAvrgRds = 0.0;
	aVrtx.clear();
	//////Varialbe define
	std::vector<CSCE>& aSCE = *m_pSCEAry;
	long iSCEAmntInCl = m_iSCETl - m_iSCEHd + 1;
	double fLngRdsIncr = 3.14 / ((double)(iLngAmnt - 1)); //radian increment in longitude line
	double fLtRdsIncr = 6.28 / ((double)iLtAmnt); //Radian increment in latitude line
	//PCL and KD Tree
	pcl::PointCloud<pcl::PointXYZ>::Ptr pCld(new pcl::PointCloud<pcl::PointXYZ>);
	pcl::KdTreeFLANN<pcl::PointXYZ> KdTr;
	double fShpIndx(0.0);
	//////Process
	//Center
	for (long iS = m_iSCEHd; iS <= m_iSCETl; ++iS)
	{
		vCntr[0] += aSCE[iS].aP()[iFrm][0];
		vCntr[1] += aSCE[iS].aP()[iFrm][1];
		vCntr[2] += aSCE[iS].aP()[iFrm][2];
	}
	vCntr[0] = vCntr[0] / ((double)iSCEAmntInCl);
	vCntr[1] = vCntr[1] / ((double)iSCEAmntInCl);
	vCntr[2] = vCntr[2] / ((double)iSCEAmntInCl);

	//Surface vertex before iterate
	{
		vector<double> vVrtx(3);
		//South pole
		vVrtx[0] = vCntr[0]; vVrtx[1] = vCntr[1]; vVrtx[2] = vCntr[2] - 2.0 * m_fDmtr;
		aVrtx.push_back(vVrtx);
		//
		for (int iLng = 1; iLng < (iLngAmnt - 1); ++iLng)
		{
			double fSbD = 2.0 * m_fDmtr * cos(-1.57 + fLngRdsIncr * ((double)iLng));
			for (int iLt = 0; iLt < iLtAmnt; ++iLt)
			{
				vVrtx[0] = vCntr[0] + fSbD * cos(fLtRdsIncr * ((double)iLt));
				vVrtx[1] = vCntr[1] + fSbD * sin(fLtRdsIncr * ((double)iLt));
				vVrtx[2] = vCntr[2] + 2.0 * m_fDmtr * sin(-1.57 + fLngRdsIncr * ((double)iLng));
				aVrtx.push_back(vVrtx);
			}
		}
		//North pole
		vVrtx[0] = vCntr[0]; vVrtx[1] = vCntr[1]; vVrtx[2] = vCntr[2] + 2.0 * m_fDmtr;
		aVrtx.push_back(vVrtx);
	}

	//develope cell surface  
	pCld->width = iSCEAmntInCl;
	pCld->height = 1;
	pCld->resize(pCld->width * pCld->height);
	for (long iS = 0; iS < iSCEAmntInCl; ++iS)
	{
		pCld->points[iS].x = aSCE[iS + m_iSCEHd].aP()[iFrm][0];
		pCld->points[iS].y = aSCE[iS + m_iSCEHd].aP()[iFrm][1];
		pCld->points[iS].z = aSCE[iS + m_iSCEHd].aP()[iFrm][2];
	}
	KdTr.setInputCloud(pCld);
	//Iterate 1
	for (int iV = 0; iV < aVrtx.size(); ++iV)
	{
		vector<double>& vVrtx = aVrtx[iV];
		//KD Tree
		pcl::PointXYZ PntCntr;
		int iK = 3;
		pcl::Indices IndxNr; 
		std::vector<float> vRdsNr;
		PntCntr.x = vVrtx[0];
		PntCntr.y = vVrtx[1];
		PntCntr.z = vVrtx[2];
		KdTr.nearestKSearch(PntCntr, iK, IndxNr, vRdsNr);
		double aOrnt[3] = { vVrtx[0] - vCntr[0], vVrtx[1] - vCntr[1], vVrtx[2] - vCntr[2] };
		double fOrntNrm = sqrt(aOrnt[0] * aOrnt[0] + aOrnt[1] * aOrnt[1] + aOrnt[2] * aOrnt[2]);
		aOrnt[0] = aOrnt[0] / fOrntNrm; aOrnt[1] = aOrnt[1] / fOrntNrm; aOrnt[2] = aOrnt[2] / fOrntNrm;
		double aNr[3] = { 0.0,0.0,0.0 };
		for (int iNr = 0; iNr < IndxNr.size(); ++iNr)
		{
			int jS = IndxNr[iNr];
			aNr[0] += pCld->points[jS].x;
			aNr[1] += pCld->points[jS].y;
			aNr[2] += pCld->points[jS].z;
		}
		double fFctrLn = CSCE::REq()/1.732 + ((aNr[0] - 3.0 * vCntr[0]) * aOrnt[0] + (aNr[1] - 3.0 * vCntr[1]) * aOrnt[1] + (aNr[2] - 3.0 * vCntr[2]) * aOrnt[2]) / 3.0;
		vVrtx[0] = vCntr[0] + fFctrLn * aOrnt[0];
		vVrtx[1] = vCntr[1] + fFctrLn * aOrnt[1];
		vVrtx[2] = vCntr[2] + fFctrLn * aOrnt[2];
	}
	//Iterate 2
	for (int iV = 0; iV < aVrtx.size(); ++iV)
	{
		vector<double>& vVrtx = aVrtx[iV];
		//KD Tree
		pcl::PointXYZ PntCntr;
		int iK = 3;
		pcl::Indices IndxNr;
		std::vector<float> vRdsNr;
		PntCntr.x = vVrtx[0];
		PntCntr.y = vVrtx[1];
		PntCntr.z = vVrtx[2];
		KdTr.nearestKSearch(PntCntr, iK, IndxNr, vRdsNr);
		double aOrnt[3] = { vVrtx[0] - vCntr[0], vVrtx[1] - vCntr[1], vVrtx[2] - vCntr[2] };
		double fOrntNrm = sqrt(aOrnt[0] * aOrnt[0] + aOrnt[1] * aOrnt[1] + aOrnt[2] * aOrnt[2]);
		aOrnt[0] = aOrnt[0] / fOrntNrm; aOrnt[1] = aOrnt[1] / fOrntNrm; aOrnt[2] = aOrnt[2] / fOrntNrm; //��λ��
		double aNr[3] = { 0.0,0.0,0.0 };
		for (int iNr = 0; iNr < IndxNr.size(); ++iNr)
		{
			int jS = IndxNr[iNr];
			aNr[0] += pCld->points[jS].x;
			aNr[1] += pCld->points[jS].y;
			aNr[2] += pCld->points[jS].z;
		}
		double fFctrLn = CSCE::REq()/1.732 + ((aNr[0] - 3.0 * vCntr[0]) * aOrnt[0] + (aNr[1] - 3.0 * vCntr[1]) * aOrnt[1] + (aNr[2] - 3.0 * vCntr[2]) * aOrnt[2]) / 3.0;
		vVrtx[0] = vCntr[0] + fFctrLn * aOrnt[0];
		vVrtx[1] = vCntr[1] + fFctrLn * aOrnt[1];
		vVrtx[2] = vCntr[2] + fFctrLn * aOrnt[2];
		//����fFctrLn
		fAvrgRds += fFctrLn;
	}

	//Average radius
	fAvrgRds = fAvrgRds/((double)aVrtx.size());

	//Shape index 2D
	if (true)
	{
		double fPrmtrZ(0.0), fPrmtrY(0.0), fPrmtrX(0.0);
		double fArZ(0.0), fArY(0.0), fArX(0.0);
		int iEqtrBgn = ((iLngAmnt - 3) / 2) * iLtAmnt + 1;
		int iEqtrEnd = ((iLngAmnt - 1) / 2) * iLtAmnt;
		//Z, shape index at Z plane
		for (int iV = iEqtrBgn; iV < iEqtrEnd; ++iV)
		{
			fPrmtrZ += sqrt(pow(aVrtx[iV][0] - aVrtx[iV + 1][0], 2) + pow(aVrtx[iV][1] - aVrtx[iV + 1][1], 2) + pow(aVrtx[iV][2] - aVrtx[iV + 1][2], 2));
			fArZ += 0.5 * sin(fLtRdsIncr) * sqrt(pow(aVrtx[iV][0] - vCntr[0], 2) + pow(aVrtx[iV][1] - vCntr[1], 2) + pow(aVrtx[iV][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iV + 1][0] - vCntr[0], 2) + pow(aVrtx[iV + 1][1] - vCntr[1], 2) + pow(aVrtx[iV + 1][2] - vCntr[2], 2));
		}
		fPrmtrZ += sqrt(pow(aVrtx[iEqtrEnd][0] - aVrtx[iEqtrBgn][0], 2) + pow(aVrtx[iEqtrEnd][1] - aVrtx[iEqtrBgn][1], 2) + pow(aVrtx[iEqtrEnd][2] - aVrtx[iEqtrBgn][2], 2));
		fArZ += 0.5 * sin(fLtRdsIncr) * sqrt(pow(aVrtx[iEqtrEnd][0] - vCntr[0], 2) + pow(aVrtx[iEqtrEnd][1] - vCntr[1], 2) + pow(aVrtx[iEqtrEnd][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iEqtrBgn][0] - vCntr[0], 2) + pow(aVrtx[iEqtrBgn][1] - vCntr[1], 2) + pow(aVrtx[iEqtrBgn][2] - vCntr[2], 2));
		//Y & X plane Shape index
		{
			//Y: 0->1
			int iA(0), iB(1);
			fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArY += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
			//Y: 0->1+iLtAmnt/2
			iB = 1 + iLtAmnt / 2;
			fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArY += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
			//X: 0->1+iLtAmnt/4
			iB = 1 + iLtAmnt / 4;
			fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArX += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
			//X: 0->1+3*iLtAmnt/4
			iB = 1 + 3 * iLtAmnt / 4;
			fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArX += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
			//
			for (int iLng = 0; iLng <= (iLngAmnt - 4); ++iLng)
			{
				//Y: iLng * iLtAmnt + 1 -> (iLng+1) * iLtAmnt + 1
				iA = iLng * iLtAmnt + 1; iB = (iLng + 1) * iLtAmnt + 1;
				fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
				fArY += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
				//Y: iLng * iLtAmnt + 1 + iLtAmnt/2 -> (iLng+1) * iLtAmnt + 1 + iLtAmnt/2
				iA = iLng * iLtAmnt + 1 + iLtAmnt / 2; iB = (iLng + 1) * iLtAmnt + 1 + iLtAmnt / 2;
				fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
				fArY += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
				//X: iLng * iLtAmnt + 1 + iLtAmnt/4 -> (iLng+1) * iLtAmnt + 1 + iLtAmnt/4
				iA = iLng * iLtAmnt + 1 + iLtAmnt / 4; iB = (iLng + 1) * iLtAmnt + 1 + iLtAmnt / 4;
				fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
				fArX += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
				//X: iLng * iLtAmnt + 1 + 3*iLtAmnt/4 -> (iLng+1) * iLtAmnt + 1 + 3*iLtAmnt/4
				iA = iLng * iLtAmnt + 1 + 3 * iLtAmnt / 4; iB = (iLng + 1) * iLtAmnt + 1 + 3 * iLtAmnt / 4;
				fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
				fArX += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
			}
			//Y: (iLngAmnt-2)*iLtAmnt + 1 -> (iLngAmnt-3) * iLtAmnt + 1
			iA = (iLngAmnt - 2) * iLtAmnt + 1; iB = (iLngAmnt - 3) * iLtAmnt + 1;
			fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArY += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
			//Y: (iLngAmnt-2)*iLtAmnt + 1 -> (iLngAmnt-3) * iLtAmnt + 1 +iLtAmnt/2
			iB = (iLngAmnt - 3) * iLtAmnt + 1 + iLtAmnt / 2;
			fPrmtrY += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArY += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
			//X: (iLngAmnt-2)*iLtAmnt + 1 -> (iLngAmnt-3) * iLtAmnt + 1 +iLtAmnt/4
			iB = (iLngAmnt - 3) * iLtAmnt + 1 + iLtAmnt / 4;
			fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArX += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
			//X: (iLngAmnt-2)*iLtAmnt + 1 -> (iLngAmnt-3) * iLtAmnt + 1 +3*iLtAmnt/4
			iB = (iLngAmnt - 3) * iLtAmnt + 1 + 3 * iLtAmnt / 4;
			fPrmtrX += sqrt(pow(aVrtx[iA][0] - aVrtx[iB][0], 2) + pow(aVrtx[iA][1] - aVrtx[iB][1], 2) + pow(aVrtx[iA][2] - aVrtx[iB][2], 2));
			fArX += 0.5 * sin(fLngRdsIncr) * sqrt(pow(aVrtx[iA][0] - vCntr[0], 2) + pow(aVrtx[iA][1] - vCntr[1], 2) + pow(aVrtx[iA][2] - vCntr[2], 2)) * sqrt(pow(aVrtx[iB][0] - vCntr[0], 2) + pow(aVrtx[iB][1] - vCntr[1], 2) + pow(aVrtx[iB][2] - vCntr[2], 2));
		}
		fShpIndx = (fPrmtrZ / sqrt(fArZ) + fPrmtrY / sqrt(fArY) + fPrmtrX / sqrt(fArX)) / 3.0;
		//std::cout<<"fPrmtrZ: "<< fPrmtrZ<<", fPrmtrY: "<<fPrmtrY<<", fPrmtrX: "<<fPrmtrX<<"\n";
		//std::cout << "fArZ: " << fArZ << ", fArY: " << fArY << ", fArX: " << fArX << "\n";
		//std::cout<<"fShpIndx: X = "<< fPrmtrX / sqrt(fArX)<<", Y = "<<fPrmtrY / sqrt(fArY)<<", Z = "<<fPrmtrZ / sqrt(fArZ)<<"\n";
	}
	/////Variable finish
	/////Normal end
	return fShpIndx;
}
//Get Center velocity
bool CCl::GtCntrVlcty(std::vector<double>& vCntr, std::vector<double>& vVlcty, const long& iFrm)
{
	//////Safe
	//////Varialbe define
	vCntr.resize(3); vCntr[0] = vCntr[1] = vCntr[2] = 0.0;
	vVlcty.resize(3); vVlcty[0] = vVlcty[1] = vVlcty[2] = 0.0;
	std::vector<CSCE>& aSCE = *m_pSCEAry;
	long iSCEAmntInCl = m_iSCETl - m_iSCEHd + 1;
	//////Process
	for (long iS = m_iSCEHd; iS <= m_iSCETl; ++iS)
	{
		//
		vCntr[0] += aSCE[iS].aP()[iFrm][0];
		vCntr[1] += aSCE[iS].aP()[iFrm][1];
		vCntr[2] += aSCE[iS].aP()[iFrm][2];
		//
		vVlcty[0] += aSCE[iS].aV()[iFrm][0];
		vVlcty[1] += aSCE[iS].aV()[iFrm][1];
		vVlcty[2] += aSCE[iS].aV()[iFrm][2];
	}
	vCntr[0] = vCntr[0] / ((double)iSCEAmntInCl);
	vCntr[1] = vCntr[1] / ((double)iSCEAmntInCl);
	vCntr[2] = vCntr[2] / ((double)iSCEAmntInCl);
	vVlcty[0] = vVlcty[0] / ((double)iSCEAmntInCl);
	vVlcty[1] = vVlcty[1] / ((double)iSCEAmntInCl);
	vVlcty[2] = vVlcty[2] / ((double)iSCEAmntInCl);
	/////Variable finish
	/////Normal end
	return true;
}

//Get Center
bool CCl::GtCntr(std::vector<double>& vCntr, const long& iFrm)
{
	//////Safe
	//////Varialbe define
	vCntr.resize(3); vCntr[0] = vCntr[1] = vCntr[2] = 0.0;
	std::vector<CSCE>& aSCE = *m_pSCEAry;
	long iSCEAmntInCl = m_iSCETl - m_iSCEHd + 1;
	//////Process
	for (long iS = m_iSCEHd; iS <= m_iSCETl; ++iS)
	{
		//
		vCntr[0] += aSCE[iS].aP()[iFrm][0];
		vCntr[1] += aSCE[iS].aP()[iFrm][1];
		vCntr[2] += aSCE[iS].aP()[iFrm][2];
	}
	vCntr[0] = vCntr[0] / ((double)iSCEAmntInCl);
	vCntr[1] = vCntr[1] / ((double)iSCEAmntInCl);
	vCntr[2] = vCntr[2] / ((double)iSCEAmntInCl);
	/////Variable finish
	/////Normal end
	return true;
}