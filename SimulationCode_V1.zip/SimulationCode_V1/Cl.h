#ifndef CL_20221015
#define CL_20221015
#include"SCE.h"


class CCl //Cell clasee
{
	//Static
public:
	static bool StSCEAry(std::vector<CSCE>* pSCEAry);
private:
	static std::vector<CSCE>* m_pSCEAry;

	//��Static
public:
	//Constructoin
	CCl() { ; }
	//Constructoin with Diamter, first SCE in SCE list, last SCE in SCE list
	CCl(const double& fDmtr, const long& iSCEHd, const long& iSCETl);
	//Destruction
	~CCl() { ; }
	//Get diameter
	double Dmtr(void) { return m_fDmtr; }
	//Get SCE Head
	long SCEHd(void) { return m_iSCEHd; }
	//Get SCE Tail
	long SCETl(void) { return m_iSCETl; }
	//Get surface vertex at a frame, iLngAmnt is amount of vertex in a longitude line, iLtAmnt is amount of vertex in a latitude line, return Shape index
	double GtSrfcVrtx(std::vector<std::vector<double>>& aVrtx,const long& iFrm, const int& iLngAmnt, const int& iLtAmnt);
	//Get Cell morphology indexes at a frame: average radius, surface vrtex, iLngAmnt is amount of vertex in a longitude line, iLtAmnt is amount of vertex in a latitude line, return Shape index
	double GtMrphlgy(std::vector<double>& vCntr, double& fAvrgRds, std::vector<std::vector<double>>& aVrtx, const long& iFrm, const int& iLngAmnt, const int& iLtAmnt);
	//Get cell center and velocity at a frame
	bool GtCntrVlcty(std::vector<double>& vCntr, std::vector<double>& vVlcty, const long& iFrm);
	//Get cell center at a frame
	bool GtCntr(std::vector<double>& vCntr, const long& iFrm);
private:
	double m_fDmtr; //Diamter of cell
	long m_iSCEHd; //first SCE index of this cell in SCE list
	long m_iSCETl; //last SCE index of this cell in SCE list
};


#endif
