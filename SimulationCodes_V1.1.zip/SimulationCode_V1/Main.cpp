#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <ctime>
#include "SCE.h"
#include "Cl.h"
#include "Embry.h"

#define ICM 0
#define FLUCTUATE 1
#define AFFINITY 2

int main(void)
{
	//////Safe
	
	//////Variable
	vector<CSCE> aSCE; //Subcellular elements list
	CCl::StSCEAry(&aSCE); //Initiate the static variable of CCl (class of Cell)
	CEmbry::StSCEAry(&aSCE); //Initiate the static variable of CEmbry (class of Embryo)
	CEmbry Embry; 

	std::string sPth("..\\Exm\\"); //Working path of input and output files 
	time_t TmStmp = time(NULL); //Time stamp for results
	tm* pTmStmp = localtime(&TmStmp);

	int iSmltn = ICM;
	//////Process
	//Simulation of 36 cells (18 pEPI and 18 pPrE) motion 
	if(iSmltn == ICM)
	{
		//Setings
		Embry.Intl(sPth + "Init_SCEProp(3600 SCE)_Attch.csv", sPth + "Init_SCEMotion(3600 SCE)_Attch.csv");
		//Embry.Intl(sPth + "SCEProp.csv", sPth + "SCEMotion.csv"); //This was used to continue a simulation after the last one. 
		CEmbry::TE() = true; //true: ICM was inside the blastocyst; false: ICM was isolated from the blastocyst
		CEmbry::Osclt() = true; //true: there is oscillations of blastocyst; false: there is no oscillations of blastocyst
		CSCE::AfntyFctr_00() = 0.26;	//PrE-PrE
		CSCE::AfntyFctr_01() = 0.23;	//EPI-PrE
		CSCE::AfntyFctr_11() = 0.4;		//EPI-EPI
		CSCE::AfntyFctr_0B() = 0.23;	//PrE-TE
		CSCE::AfntyFctr_1B() = 0.4;		//EPI-TE

		CEmbry::TShrnk() = 30.0; //Time of contraction in one cycle
		CEmbry::TExpnd() = 1800.0; //Time of expansion in one cycle
		CEmbry::THld() = 0.0; //Interval time between cycles
		double fTCycl = CEmbry::TShrnk() + CEmbry::TExpnd() + CEmbry::THld();
		Embry.StT(0, fTCycl*8); //Set the simulatoin time, from 0s to 8 cycles tie

		//Run
		std::wcout << "Running ...\n";
		CSCE::Run(aSCE, 20e-3); //3.0e-3

		//Export results
		std::cout << "Exporting results ...\n";
		std::stringstream ssTmStmp, ssSCEStmp, ssClStmp, ssNt;
		ssTmStmp << "_" << (1900 + pTmStmp->tm_year) * 10000 + (1 + pTmStmp->tm_mon) * 100 + (pTmStmp->tm_mday);
		ssTmStmp << "(" << std::right << std::setfill('0') << std::setw(4) << (pTmStmp->tm_hour) * 100 + (pTmStmp->tm_min) << ")";
		ssSCEStmp << "(" << aSCE.size() << " SCE)";
		ssClStmp << "(" << Embry.aCl().size() << " Cell)";

		//SCE Properties & Motion
		Embry.ExprtSCEPrp(sPth + "SCEProp.csv"); //Export the SCE properties 
		Embry.ExprtSCEPrp(sPth + "SCEProp" + ssSCEStmp.str() + ssTmStmp.str() + ".csv"); //Export the SCE properties with time stamp (for backup)

		Embry.ExprtSCEMtn(sPth + "SCEMotion.csv"); //Export the SCE motion information
		Embry.ExprtSCEMtn(sPth + "SCEMotion" + ssSCEStmp.str() + ssTmStmp.str() + ".csv"); //Export the SCE motion information with time stamp (for backup)

		//Cell Properties & Motion
		Embry.ExprtClPrp(sPth + "CellProp.csv", 25, 36); //Export the cell properties, with the vertex resolution in longitude and latitude lines of 25 and 36
		Embry.ExprtClPrp(sPth + "CellProp" + ssClStmp.str() + ssTmStmp.str() + ".csv", 25, 36); //Export the cell properties  with time stamp (for backup)

		Embry.ExprtClMtn(sPth + "CellMotion.csv", 25, 36); //Export the cell motion information
		Embry.ExprtClMtn(sPth + "CellMotion" + ssClStmp.str() + ssTmStmp.str() + ".csv", 25, 36); //Export the cell motion information with time stamp (for backup)

		Embry.ExprtClVlcty(sPth + "CellVelocity.csv"); //Export the motion and velocity information of cell centers.
		Embry.ExprtClVlcty(sPth + "CellVelocity" + ssClStmp.str() + ssTmStmp.str() + ".csv"); 

		///Sorting index
		std::cout << "Sort index: \n";
		Embry.ExprtSrtIndx(sPth + "SortIndex" + ssClStmp.str() + ssTmStmp.str() + ".csv"); //Export the sorting index over time
		//Embry.ShwSrtIndx();
	}
	//To quantify surface fluctuations of different cells, the surface properties should be changed to pEPI or pPrE (fEPIFlc,fEPIStf, fPrEFlc and fPrEStf in F() of SCE.cpp)
	if (iSmltn == FLUCTUATE)
	{
		//Initial position
		Embry.Intl(sPth + "Init_SCEProp(100 SCE)_Float.csv", sPth + "Init_SCEMotion(100 SCE)_Float.csv");
		//T
		CSCE::aT().clear();
		double fTIncr = 15.0; //[s]
		for (double fT = 0.0; fT <= 750.0; fT += fTIncr)
		{
			CSCE::aT().push_back(fT);
		}
		//Run
		CSCE::Run(aSCE, 20e-3); //3.0e-3
		//Result
		std::cout << "Morphology: \n";
		Embry.Mrphlgy();
	}
	//To quantify affinity of different cell doublets, the surface properties should be changed to pEPI-pEPI, pPrE-pPrE or pEPI-pPrE (fEPIFlc,fEPIStf, fPrEFlc and fPrEStf in F() of SCE.cpp)
	if (iSmltn == AFFINITY) //Quantify 
	{
		//Initial position
		Embry.Intl(sPth + "Init_SCEProp(200 SCE)_Float.csv", sPth + "Init_SCEMotion(200 SCE)_Float.csv");
		//T
		CSCE::aT().clear();
		double fTIncr = 15.0; //[s]
		for (double fT = 0.0; fT <= 750.0; fT += fTIncr)
		{
			CSCE::aT().push_back(fT);
		}
		//Affinity
		CSCE::AfntyFctr_01() = 0.26; //
		//Run
		CSCE::Run(aSCE, 20e-3); //3.0e-3
		//Result
		std::cout << "Morphology: \n";
		Embry.Mrphlgy();
	}
	//////Finish Variable

	//////Normal end
	time_t TmEnd = time(NULL);
	std::cout << "SCE done, last "<<(TmEnd-TmStmp)/60.0<<" mins\n";
	return 0;
}