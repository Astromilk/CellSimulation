#include "Embry.h"
#include <cmath>
#include <omp.h>
#include <fstream>
#include <sstream>
#include <stdlib.h>

vector<CSCE>* CEmbry::m_pSCEAry;
double CEmbry::m_fTShrnk = 30.0; //the duration of one contraction, 30s
double CEmbry::m_fTExpnd = 1800.0; //the duration of one expansion, 1800s
double CEmbry::m_fTHld = 0.0; //the interval time between two cycles 
double CEmbry::m_fTPrpr = 30.0; //Reference time for initial condition development
bool CEmbry::m_bTE = true; //if ICM is isolated from blastocyst
bool CEmbry::m_bOsclt = true; //if blastocyst oscilation.

bool CEmbry::StSCEAry(vector<CSCE>* pSCEAry)
{
	m_pSCEAry = pSCEAry;
	return true;

}

double CEmbry::Dmtr_(const double& fT)
{
	//////Safe
	//////Varialbe define
	double fDmtr(0.0); 
	double fDmtr0(80.0); //um, Initial diameter
	double fDmtrMn(60.0); //Min diameter
	double fDmtrMx(80.0); //Max diameter

	//////Process
	if (m_bOsclt) //If oscillation
	{
		//If fT<0: at the development of initial condition
		if (fT < (-1.0 * m_fTPrpr)) //fT<-m_fTPrpr
		{
			fDmtr = fDmtr0;
		}
		else if (((-1.0 * m_fTPrpr) <= fT) && (fT < 0)) // -m_fTPrpr<=fT<0
		{
			fDmtr = fDmtr0 + ((fT + m_fTPrpr) * (fDmtrMx - fDmtr0) / m_fTPrpr);
		}
		else //If fT>=0. Simulation of cell motion
		{
			double fCyclNO = (int)(fT / (m_fTShrnk + m_fTExpnd)); //Cycle times
			double fTInCycl = fT - fCyclNO * (m_fTShrnk + m_fTExpnd); //The time at one oscillation
			if ((fTInCycl >= 0) && (fTInCycl < m_fTShrnk)) //Contraction
			{
				fDmtr = fDmtrMx + (fTInCycl * (fDmtrMn - fDmtrMx) / m_fTShrnk);								
			}
			else //Expand
			{
				fDmtr = fDmtrMn + ((fTInCycl - m_fTShrnk) * (fDmtrMx - fDmtrMn) / m_fTExpnd);
			}
		}
	}
	else
	{
		fDmtr = fDmtrMx;
	}
	/////Variable finish
	/////Normal end
	return fDmtr;
}

double CEmbry::Dmtr_AdHld(const double& fT)
{
	//////Safe
	//////Varialbe define
	double fDmtr(0.0); 
	double fDmtr0(80.0); //um, Initial diameter
	double fDmtrMn(60.0); //Min diameter
	double fDmtrMx(80.0); //Max diameter
	//////Process
	if (m_bOsclt) //If oscillation
	{
		//If fT<0: at the development of initial condition
		if (fT < (-1.0 * m_fTPrpr)) //fT<-m_fTPrpr
		{
			fDmtr = fDmtr0;
		}
		else if (((-1.0 * m_fTPrpr) <= fT) && (fT < 0)) //-m_fTPrpr<=fT<0
		{
			fDmtr = fDmtr0 + ((fT + m_fTPrpr) * (fDmtrMx - fDmtr0) / m_fTPrpr);
		}
		else //If fT>=0. Simulation of cell motion
		{
			double fCyclNO = (int)(fT / (m_fTShrnk + m_fTExpnd + m_fTHld)); //Cycle times
			double fTInCycl = fT - fCyclNO * (m_fTShrnk + m_fTExpnd + m_fTHld); //time at one oscillation
			if ((fTInCycl >= 0) && (fTInCycl < m_fTShrnk)) //Contraction phase
			{
				fDmtr = fDmtrMx + (fTInCycl * (fDmtrMn - fDmtrMx) / m_fTShrnk); 
		
			}
			else if ((fTInCycl >= m_fTShrnk) && (fTInCycl < (m_fTShrnk + m_fTExpnd)))//Expand 
			{
				fDmtr = fDmtrMn + ((fTInCycl - m_fTShrnk) * (fDmtrMx - fDmtrMn) / m_fTExpnd);
			}
			else //Hold 
			{
				fDmtr = fDmtrMx;
			}
		}
	}
	else
	{
		fDmtr = fDmtrMx;
	}
	/////Variable finish
	/////Normal end
	return fDmtr;
}

CEmbry::CEmbry()
{
	//////Safe
	//////Varialbe define
	//////Process
	m_aCl.clear();
	/////Variable finish
	/////Normal end
}

bool CEmbry::AdCl(const double& fC, const int& iTyp, const double& fDmtr, const int& iSCEAmntInCl, const double& fX0, const double& fY0, const double& fZ0)
{
	//////Safe
	//////Varialbe define
	vector<CSCE>& aSCE = *m_pSCEAry;
	long iSCEAmnt = aSCE.size();
	long iSCE = 0; //Count SCE NO
	int iCbSdNO = (int)cbrt((double)iSCEAmntInCl);
	double fCbSdLngth = ((double)(iCbSdNO - 1)) * (CSCE::REq());
	//////Process
	//Update m_aCl
	CCl Cl(fDmtr, iSCEAmnt, iSCEAmnt+iSCEAmntInCl-1);
	m_aCl.push_back(Cl);
	//Update aSCE
	for (int iX = 0; ; ++iX)
	{
		for (int iY = 0; iY < iCbSdNO; ++iY)
		{
			for (int iZ = 0; iZ < iCbSdNO; ++iZ)
			{
				double fX = -0.5 * fCbSdLngth + ((double)iX) * (CSCE::REq());
				double fY = -0.5 * fCbSdLngth + ((double)iY) * (CSCE::REq());
				double fZ = -0.5 * fCbSdLngth + ((double)iZ) * (CSCE::REq());
				CSCE SCE(fC/((double)iSCEAmntInCl), m_aCl.size()-1, iTyp, fX0+fX, fY0+fY, fZ0+fZ, 0, 0, 0);
				m_pSCEAry->push_back(SCE);
				++iSCE;
				if (iSCE >= iSCEAmntInCl) { return true; }
			}
		}
	}
	/////Variable finish
	/////Normal end
	return true;
}

//Intial Embryo
bool CEmbry::Intl(const int& iXAmnt, const int& iYAmnt, const int& iZAmnt)
{
	//////Safe
	m_aCl.clear();
	m_pSCEAry->clear();
	//////Varialbe define
	double fClDmtr = 13.0;
	int iSCEAmntInCl = 100;
	double fC = 5.0; //[Modeling cell rheology with the Subcellular Element Model]��0. 
	//////Process
	///1. Initial Morse Potential parameters
	CSCE::IntlMrsPtntlPrm(fClDmtr, iSCEAmntInCl);
	///2. Initial Cell and SCE
	{
		bool bXTyp(false), bYTyp(false), bZTyp(false); //Used to make the neighbour cells different
		for (int iY = 0; iY < iYAmnt; ++iY)
		{
			bXTyp = bYTyp;
			for (int iX = 0; iX < iXAmnt; ++iX)
			{
				bZTyp = !bXTyp;
				for (int iZ = 0; iZ < iZAmnt; ++iZ)
				{
					double fX = -0.5 * fClDmtr * (double(iXAmnt - 1)) + (double(iX)) * fClDmtr;
					double fY = -0.5 * fClDmtr * (double(iYAmnt - 1)) + (double(iY)) * fClDmtr;
					double fZ = -0.5 * fClDmtr * (double(iZAmnt - 1)) + (double(iZ)) * fClDmtr;
					int iTyp = 0; if (bZTyp) { iTyp = 1; }
					AdCl(fC, iTyp, fClDmtr, iSCEAmntInCl, fX, fY, fZ);
					bZTyp = !bZTyp;
				}
				bXTyp = !bXTyp;//bYTyp = !bYTyp;
			}
			bYTyp = !bYTyp;//bXTyp = !bXTyp;
		}
	}
	///3. Kd Tree
	CSCE::IntlPclKdTr(*m_pSCEAry);
	/////Variable finish
	/////Normal end
	return true;
}

//Intial Embryo from file,
bool CEmbry::Intl(const string& sPthSCEPrp, const string& sPthSCEMtn, const double& iFrm)
{
	//////Safe
	m_aCl.clear();
	m_pSCEAry->clear();
	//////Varialbe define
	std::fstream fCsvSCEPrp(sPthSCEPrp, std::ios::in);
	std::fstream fCsvSCEMtn(sPthSCEMtn, std::ios::in);

	//////Process
	///1&2. Initial Morse Potential parameters, & Cell and SCE properties
	if (fCsvSCEPrp.is_open())
	{
		std::string sLn;
		//Get SCE Static variable line by line
		std::getline(fCsvSCEPrp, sLn); //REq
		CSCE::REq() = atof((Split(sLn, ',')[1]).c_str());
		std::getline(fCsvSCEPrp, sLn); //Rou
		CSCE::Rou() = atof((Split(sLn, ',')[1]).c_str());
		std::getline(fCsvSCEPrp, sLn); //U0
		CSCE::U0() = atof((Split(sLn, ',')[1]).c_str());
		std::getline(fCsvSCEPrp, sLn); //K
		CSCE::K() = atof((Split(sLn, ',')[1]).c_str());
		//20220927. Add
		std::getline(fCsvSCEPrp, sLn); //m_fCntctFctr; 
		CSCE::CntctFctr() = atof((Split(sLn, ',')[1]).c_str());
		std::getline(fCsvSCEPrp, sLn); //m_fAfntyFctr_In; 
		CSCE::AfntyFctr_Intr() = atof((Split(sLn, ',')[1]).c_str());
		std::getline(fCsvSCEPrp, sLn); //m_fAfntyFctr_00; 
		CSCE::AfntyFctr_00() = atof((Split(sLn, ',')[1]).c_str());
		std::getline(fCsvSCEPrp, sLn); //m_fAfntyFctr_01; 
		CSCE::AfntyFctr_01() = atof((Split(sLn, ',')[1]).c_str());
		std::getline(fCsvSCEPrp, sLn); //m_fAfntyFctr_11; 
		CSCE::AfntyFctr_11() = atof((Split(sLn, ',')[1]).c_str());
		std::getline(fCsvSCEPrp, sLn); //m_fAfntyFctr_0B; 
		CSCE::AfntyFctr_0B() = atof((Split(sLn, ',')[1]).c_str());
		std::getline(fCsvSCEPrp, sLn); //m_fAfntyFctr_1B; 
		CSCE::AfntyFctr_1B() = atof((Split(sLn, ',')[1]).c_str());
		//Get SCE non static variable line by line, update m_cSCE
		for (;;)
		{
			std::getline(fCsvSCEPrp, sLn);
			if (sLn.empty())
			{
				break;
			}
			else
			{
				vector<string> aDt = Split(sLn, ',');
				if (aDt[0].find("SCE") == 0) //SCE Data
				{
					double fC = atof(aDt[1].c_str());
					double iCl = atof(aDt[2].c_str());
					double iTyp = atof(aDt[3].c_str());
					double fPhs = atof(aDt[4].c_str());
					CSCE SCE(fC, iCl, iTyp, 0, 0, 0, 0, 0, 0);
					SCE.Phs() = fPhs;
					m_pSCEAry->push_back(SCE);
				}
				else if (aDt[0].find("Cell") == 0) //Cell Data
				{
					double fDmtr = atof(aDt[1].c_str());
					long iSCEHd = atof(aDt[2].c_str());
					long iSCETl = atof(aDt[3].c_str());
					CCl Cl(fDmtr, iSCEHd, iSCETl);
					m_aCl.push_back(Cl);
				}				
			}
		}
		//Close file
		fCsvSCEPrp.close();
	}

	///3. Initial SCE motion
	if (fCsvSCEMtn.is_open())
	{
		std::string sLn, sLnTmp;
		std::getline(fCsvSCEMtn, sLn); //Comment line
		if (iFrm < 0) //
		{
			for (long iLn = 0; ; ++iLn) //The target frame or last frame
			{
				std::getline(fCsvSCEMtn, sLnTmp); //data line
				if (sLnTmp.empty())
				{
					break;
				}
				sLn = sLnTmp;
			}
		}
		else //Data of iFrm
		{
			for (long iLn = 0; iLn <= iFrm; ++iLn)
			{
				std::getline(fCsvSCEMtn, sLnTmp); 
				if (sLnTmp.empty())
				{
					break;
				}
				sLn = sLnTmp;
			}
		}
		vector<string> aDt = Split(sLn, ',');
		//Update m_cSCE[i] m_cP/V[0]
		for (long iSCE = 0; iSCE < m_pSCEAry->size(); ++iSCE)
		{
			CSCE& SCE = (*m_pSCEAry)[iSCE];
			//P
			SCE.aP()[0][0] = atof(aDt[6*iSCE + 2].c_str());
			SCE.aP()[0][1] = atof(aDt[6*iSCE + 3].c_str());
			SCE.aP()[0][2] = atof(aDt[6*iSCE + 4].c_str());
			//V
			SCE.aV()[0][0] = atof(aDt[6*iSCE + 5].c_str());
			SCE.aV()[0][1] = atof(aDt[6*iSCE + 6].c_str());
			SCE.aV()[0][2] = atof(aDt[6*iSCE + 7].c_str());
		}
		//Close file
		fCsvSCEMtn.close();
	}

	///4. KdTree
	CSCE::IntlPclKdTr(*m_pSCEAry);
	//////Variable end
	//////Normal end
	return false;
}

//Set Time
bool CEmbry::StT(const double& fTBgn, const double& fTEnd)
{
	//////Safe
	CSCE::aT().clear();
	//////Varialbe define
	double fTIncr = 0.0; //[s]
	double fTCycl = m_fTShrnk + m_fTExpnd +m_fTHld;
	//////Process
	for (double fT = fTBgn; fT <= fTEnd;)
	{
		CSCE::aT().push_back(fT);
		if (fTEnd <= 0.0) //If at development of initial condition
		{
			fTIncr = (fTEnd - fTBgn) / 30.0;
		}
		else //If simulation of cell motion
		{
			double fCyclNO = (int)(fT / fTCycl); //cycle times
			double fTInCycl = fT - fCyclNO * fTCycl; //Time at one oscillatoin
			if ((fTInCycl >= 0) && (fTInCycl < m_fTShrnk)) //Contraction
			{
				fTIncr = m_fTShrnk / 5.0;
			}
			else //Expand
			{
				fTIncr = m_fTExpnd / 15.0;
			}
		}
		fT += fTIncr;
	}
	/////Variable finish

	//////Process
	/////Normal end
	return true;
}

//Export SCE properties (Diameter, Color)
bool CEmbry::ExprtSCEPrp(const string& sPth)
{
	//////Safe
	//////Varialbe define
	std::fstream fCsv(sPth, std::ios::out);
	//////Process
	if (fCsv.is_open())
	{
		//Static parameters
		fCsv << "REq," << CSCE::REq() << "\n";
		fCsv << "Rou," << CSCE::Rou() << "\n";
		fCsv << "U0," << CSCE::U0() << "\n";
		fCsv << "K," << CSCE::K() << "\n";

		fCsv << "CntctFctr," << CSCE::CntctFctr() << "\n";
		fCsv << "AfntyFctr_Intr," << CSCE::AfntyFctr_Intr() << "\n";
		fCsv << "AfntyFctr_00," << CSCE::AfntyFctr_00() << "\n";
		fCsv << "AfntyFctr_01," << CSCE::AfntyFctr_01() << "\n";
		fCsv << "AfntyFctr_11," << CSCE::AfntyFctr_11() << "\n";
		fCsv << "AfntyFctr_0B," << CSCE::AfntyFctr_0B() << "\n";
		fCsv << "AfntyFctr_1B," << CSCE::AfntyFctr_1B() << "\n";

		//Non static parameters
		//SCE
		for (long i = 0; i < m_pSCEAry->size(); ++i)
		{
			CSCE& SCE = (*m_pSCEAry)[i];
			fCsv << "SCE " << i << "(C/Cell Id/Type/Phase)," << SCE.C() << "," << SCE.Cl() << "," << SCE.Typ() << "," << SCE.Phs() << "\n";
		}
		//Cell
		for (long i = 0; i < m_aCl.size(); ++i)
		{
			CCl& Cl = m_aCl[i];
			fCsv << "Cell " << i << "(Diameter/SCE ID Begin/SCE ID End)," << Cl.Dmtr() << "," << Cl.SCEHd() << "," << Cl.SCETl() << "\n";
		}
		fCsv.close();
	}
	else
	{
		return false;
	}
	/////Variable finish
	/////Normal end
	return true;
}

//Export Embryo motion. First line is comment, Columnes are fT, Embryo Diameter, SCE_iCell_iSCE_X, SCE_iCell_iSCE_Y, SCE_iCell_iSCE_Z  
bool CEmbry::ExprtSCEMtn(const string& sPth)
{
	//////Safe
	//////Varialbe define
	vector<double>& aT = CSCE::aT();
	vector<CSCE>& aSCE = *m_pSCEAry;
	std::fstream fCsv(sPth, std::ios::out);
	//////Process
	if (fCsv.is_open())
	{
		//Line 0, Comment
		fCsv << "Time (s)";
		fCsv << ",Embryo Diameter (um)";
		for (long i = 0; i < m_pSCEAry->size(); ++i)
		{
			fCsv << ",";
			fCsv << "SCE(" << i << ")_Px,";
			fCsv << "SCE(" << i << ")_Py,";
			fCsv << "SCE(" << i << ")_Pz,";
			fCsv << "SCE(" << i << ")_Vx,";
			fCsv << "SCE(" << i << ")_Vy,";
			fCsv << "SCE(" << i << ")_Vz";
		}
		fCsv << "\n";
		//Data lines
		for (long iFrm = 0; iFrm < aSCE[0].aP().size(); ++iFrm)
		{
			fCsv << aT[iFrm];
			fCsv << "," << Dmtr_AdHld(aT[iFrm]);
			for (long i = 0; i < aSCE.size(); ++i)
			{
				CSCE& SCE = aSCE[i];
				vector<double>& vP = SCE.aP()[iFrm];
				vector<double>& vV = SCE.aV()[iFrm];
				fCsv << ",";
				fCsv << vP[0] << "," << vP[1] << "," << vP[2] << ",";
				fCsv << vV[0] << "," << vV[1] << "," << vV[2];
			}
			fCsv << "\n";
		}
		fCsv.close();
	}
	else
	{
		return false;
	}
	/////Variable finish
	/////Normal end
	return true;
}

//Export Cell properties (Diameter, Color)
bool CEmbry::ExprtClPrp(const string& sPth, const int& iLngAmnt, const int& iLtAmnt)
{
	//////Safe
	//////Varialbe define
	std::fstream fCsv(sPth, std::ios::out);
	vector<CSCE>& aSCE = *m_pSCEAry;
	//////Process
	if (fCsv.is_open())
	{
		fCsv << "Vertex amount in longitude," << iLngAmnt << "\n";
		fCsv << "Vertex amount in latitude," << iLtAmnt << "\n";

		for (long i = 0; i < m_aCl.size(); ++i)
		{
			CCl& Cl = m_aCl[i];
			fCsv << "Cell " << i << "(Type/)," << aSCE[Cl.SCEHd()].Typ() << "\n";
		}
		fCsv.close();
	}
	else
	{
		return false;
	}
	/////Variable finish
	/////Normal end
	return true;
}

//Export Cell motion
bool CEmbry::ExprtClMtn(const string& sPth, const int& iLngAmnt, const int& iLtAmnt)
{
	//////Safe
	//////Varialbe define
	std::vector<double>& aT = CSCE::aT();
	std::vector<CCl>& aCl = m_aCl;
	int iVrtxAmntInCl = (iLngAmnt - 2) * iLtAmnt + 2;
	std::vector<CSCE>& aSCE = *m_pSCEAry;
	std::fstream fCsv(sPth, std::ios::out);
	//Shape Index
	std::vector<std::vector<double>> aShpIndx(aCl.size());// aShpIndx[iC][iFrm] = iC's cell shape index at frame
	std::vector <std::vector<std::vector<std::vector<double>>>> aSrfcFlc(aCl.size());// aSrfcFlc[iC][iFrm] = aSrfcVrtx
	//////Process
	if (fCsv.is_open())
	{
		//Line 0, comment
		fCsv << "Time (s)";
		fCsv << ",Embryo Diameter (um)";
		for (long iC = 0; iC < aCl.size(); ++iC)
		{
			for (int iV = 0; iV < iVrtxAmntInCl; ++iV)
			{
				fCsv << ",";
				fCsv << "Vertex(" << iC<<"-"<<iV << ")_Px,";
				fCsv << "Vertex(" << iC<<"-"<<iV << ")_Py,";
				fCsv << "Vertex(" << iC<<"-"<<iV << ")_Pz";
			}
		}
		fCsv << "\n";
		//data
		for (long iFrm = 0; iFrm < aSCE[0].aP().size(); ++iFrm)
		{
			fCsv << aT[iFrm];
			fCsv << "," << Dmtr_AdHld(aT[iFrm]);
			for (long iC = 0; iC < aCl.size(); ++iC)
			{
				std::vector<std::vector<double>> aSrfcVrtx;
				double fShpIndx = aCl[iC].GtSrfcVrtx(aSrfcVrtx, iFrm, iLngAmnt, iLtAmnt);
				aShpIndx[iC].push_back(fShpIndx);
				aSrfcFlc[iC].push_back(aSrfcVrtx);
				//std::cout << "aSrfcVrtx Amount: " << aSrfcVrtx.size() << " Dim: " << aSrfcVrtx[0].size() << "\n";
				for (int iV = 0; iV < iVrtxAmntInCl; ++iV)
				{
					fCsv << ",";
					fCsv << aSrfcVrtx[iV][0] << "," << aSrfcVrtx[iV][1] << "," << aSrfcVrtx[iV][2];
				}
			}
			fCsv << "\n";
		}
		fCsv.close();
	}
	else
	{
		return false;
	}

	if (true) //Shape index
	{
		for (int iC = 0; iC < aShpIndx.size(); ++iC)
		{
			double fAvrg(0.0);
			double fSD(0.0);
			for (int iF = 0; iF < aShpIndx[iC].size(); ++iF)
			{
				fAvrg += aShpIndx[iC][iF];
			}
			fAvrg = fAvrg / ((double)aShpIndx[iC].size());
			for (int iF = 0; iF < aShpIndx[iC].size(); ++iF)
			{
				fSD += pow(aShpIndx[iC][iF] - fAvrg,2);
			}
			fSD = sqrt( fSD/((double)aShpIndx[iC].size()) );
			//std::cout<<"Shape index: Cell = "<<iC<<", Average = "<< fAvrg <<", SD = "<<fSD<<", Variation coefficient = "<<fSD/fAvrg<<"\n";
		}
		for (int iC = 0; iC < aSrfcFlc.size(); ++iC)
		{
			std::vector<std::vector<double>> aVrxtRds(iVrtxAmntInCl); //aVrxtRds[iV][iF] = Radius
			double fAvrgSDInCl(0.0), fAvrgRdsInCl(0.0); //fAvrgSDInCl is the fluctuate index of the cell, fAvrgRdsInCl is for Debug
			//aVrxtRds, distance between surface vertex and cell center
			for (int iF = 0; iF < aSrfcFlc[iC].size(); ++iF)
			{
				double vCntr[3] = { 0,0,0 };
				for (int iV = 0; iV < iVrtxAmntInCl; ++iV)
				{
					std::vector<double>& vVrtx = aSrfcFlc[iC][iF][iV];
					vCntr[0] += vVrtx[0];
					vCntr[1] += vVrtx[1];
					vCntr[2] += vVrtx[2];
				}
				vCntr[0] = vCntr[0]/((double)aSrfcFlc[iC][iF].size());
				vCntr[1] = vCntr[1]/((double)aSrfcFlc[iC][iF].size());
				vCntr[2] = vCntr[2]/((double)aSrfcFlc[iC][iF].size());
				for (int iV = 0; iV < aSrfcFlc[iC][iF].size(); ++iV)
				{
					std::vector<double>& vVrtx = aSrfcFlc[iC][iF][iV];
					double fRds = sqrt( pow(vVrtx[0]-vCntr[0],2) + pow(vVrtx[1]-vCntr[1],2) + pow(vVrtx[2]-vCntr[2],2) );
					aVrxtRds[iV].push_back(fRds);					
				}
			}
			//Calculate fAvrgSDInCl with aVrxtRds
			for (int iV = 0; iV < iVrtxAmntInCl; ++iV)
			{
				double fAvrgRds(0.0), fSDRds(0.0);
				for (int iF = 0; iF < aVrxtRds[iV].size(); ++iF)
				{
					fAvrgRds += aVrxtRds[iV][iF];
				}
				fAvrgRds = fAvrgRds/((double)aVrxtRds[iV].size());
				fAvrgRdsInCl += fAvrgRds; //fAvrgRds is for Debug
				for (int iF = 0; iF < aVrxtRds[iV].size(); ++iF)
				{
					fSDRds+=pow(aVrxtRds[iV][iF] - fAvrgRds,2);
				}
				fSDRds = sqrt( fSDRds/((double)aVrxtRds[iV].size()) ); //iV's vertex-center distance SD over time
				fAvrgSDInCl += fSDRds;
			}
			fAvrgSDInCl = fAvrgSDInCl / ((double)iVrtxAmntInCl); //Cell's Fluctuation index
			fAvrgRdsInCl = fAvrgRdsInCl / ((double)iVrtxAmntInCl);
			//std::cout << "Surface fluc: Cell = " << iC << ", Fluc = " << fAvrgSDInCl << ", Average Radius = " << fAvrgRdsInCl << "\n";
		}
		//Affinity
		if (aCl.size() == 2)
		{
			double fCntrDstnc(0.0);
			for (long iFrm = 0; iFrm < aSCE[0].aP().size(); ++iFrm)
			{
				std::vector<double> vCA; aCl[0].GtCntr(vCA, iFrm);
				std::vector<double> vCB; aCl[1].GtCntr(vCB, iFrm);
				fCntrDstnc += sqrt(pow(vCA[0] - vCB[0], 2) + pow(vCA[1] - vCB[1], 2) + pow(vCA[2] - vCB[2], 2)); //Distance between two cell centers
			}

		}
		
	}
	/////Variable finish
	/////Normal end
	return true;
}

//Export Cell motion
bool CEmbry::ExprtClVlcty(const string& sPth)
{
	//////Safe
	//////Varialbe define
	std::vector<double>& aT = CSCE::aT();
	std::vector<CCl>& aCl = m_aCl;
	std::vector<CSCE>& aSCE = *m_pSCEAry;
	std::fstream fCsv(sPth, std::ios::out);
	//Affinity
	double fCntrDstnc(0.0);
	//////Process
	if (fCsv.is_open())
	{
		//Line 0, comment
		fCsv << "Time (s)";
		fCsv << ",Embryo Diameter (um)";
		for (long iC = 0; iC < aCl.size(); ++iC)
		{
			fCsv << ",";
			fCsv << "Cell(" << iC << ")_Px,";
			fCsv << "Cell(" << iC << ")_Py,";
			fCsv << "Cell(" << iC << ")_Pz,";
			fCsv << "Cell(" << iC << ")_Vx,";
			fCsv << "Cell(" << iC << ")_Vy,";
			fCsv << "Cell(" << iC << ")_Vz";
		}
		fCsv << "\n";
		//Data
		for (long iFrm = 0; iFrm < aSCE[0].aP().size(); ++iFrm)
		{
			//{Affinity
			std::vector<std::vector<double>> aCntr;
			//}Affinity
			fCsv << aT[iFrm];
			fCsv << "," << Dmtr_AdHld(aT[iFrm]);
			for (long iC = 0; iC < aCl.size(); ++iC)
			{
				std::vector<double> vCntr, vVlcty;
				aCl[iC].GtCntrVlcty(vCntr, vVlcty, iFrm);
				fCsv << ",";
				fCsv << vCntr[0] << "," << vCntr[1] << "," << vCntr[2] << ",";
				fCsv << vVlcty[0] << "," << vVlcty[1] << "," << vVlcty[2];
				//{Affinity
				aCntr.push_back(vCntr);
				//}Affinity
			}
			fCsv << "\n";
			//{Affinity
			if (aCntr.size() == 2)
			{
				std::vector<double>& vCA = aCntr[0];
				std::vector<double>& vCB = aCntr[1];
				fCntrDstnc += sqrt( pow(vCA[0]-vCB[0],2) + pow(vCA[1]-vCB[1],2) + pow(vCA[2]-vCB[2],2) ); //�����ľ���
			}
			//}Affinity
		}
		fCsv.close();
		//Affinity
		//std::cout << "Average Disctance = " << fCntrDstnc / ((double)aSCE[0].aP().size()) << "\n";
		//Affninty
	}
	else
	{
		//CElrTp::Err("CEmbry::ExprtEmbryMtn(). Open file fail.");
		return false;
	}

	/////Variable finish
	/////Normal end
	return true;
}

//Export sort index
bool CEmbry::ExprtSrtIndx(const string& sPth)
{
	//////Safe
	//////Varialbe define
	std::vector<double>& aT = CSCE::aT();
	std::fstream fCsv(sPth, std::ios::out);
	/////Process
	if (fCsv.is_open())
	{
		//Line 0, comment
		fCsv << "Time (s)";
		fCsv << ",Sort index";
		fCsv << "\n";
		//Data lines
		for (int iFrm = 0; iFrm < aT.size(); ++iFrm)
		{
			fCsv<<aT[iFrm]<<","<<SrtIndx(1, iFrm)<<"\n";
		}
	}
	fCsv.close();
	/////Variable finish
	/////Normal end
	return true;
}

//Show sort index
bool CEmbry::ShwSrtIndx()
{
	//////Safe
	//////Varialbe define
	std::vector<double>& aT = CSCE::aT();
	/////Process
	for (int iFrm = 0; iFrm < aT.size(); ++iFrm)
	{
		std::cout << "Frame: " << iFrm << ",\tT: " << aT[iFrm] << ",\tSort: " << SrtIndx(1, iFrm) << "\n";
	}
	/////Variable finish
	/////Normal end
	return true;
}

//Get Sort index at a frame
double CEmbry::SrtIndx(const int& iInsdTyr, const long& iFrm)
{
	//////Safe
	//////Varialbe define
	std::vector<CSCE>& aSCE = *m_pSCEAry;
	std::vector<std::vector<double>> aInsdCl, aOtsdCl; //Inside Cell & Outside Cell
	int iTrpAmnt(0.0); //The outside cell NO trapped in the aInsdCl cluster
	double vInsdCntr[3] = { 0.0,0.0,0.0 };
	//PCL and KD Tree
	pcl::PointCloud<pcl::PointXYZ>::Ptr pCld(new pcl::PointCloud<pcl::PointXYZ>);
	pcl::KdTreeFLANN<pcl::PointXYZ> KdTr;
	//////Process
	//Dived m_aCl into Inside and Outside
	for (int iC = 0; iC < m_aCl.size(); ++iC)
	{
		std::vector<double> vCntr;
		m_aCl[iC].GtCntr(vCntr, iFrm);
		int iTyp = aSCE[m_aCl[iC].SCEHd()].Typ();
		if (iTyp == iInsdTyr)
		{
			aInsdCl.push_back(vCntr);
			vInsdCntr[0] += vCntr[0];
			vInsdCntr[1] += vCntr[1];
			vInsdCntr[2] += vCntr[2];
		}
		else
		{
			aOtsdCl.push_back(vCntr);
		}
	}
	vInsdCntr[0] = vInsdCntr[0] / ((double)aInsdCl.size());
	vInsdCntr[1] = vInsdCntr[1] / ((double)aInsdCl.size());
	vInsdCntr[2] = vInsdCntr[2] / ((double)aInsdCl.size());
	// Inside Cell's KD Tree, 
	pCld->width = aInsdCl.size();
	pCld->height = 1;
	pCld->resize(pCld->width * pCld->height);
	for (long iC = 0; iC < aInsdCl.size(); ++iC)
	{
		pCld->points[iC].x = aInsdCl[iC][0];
		pCld->points[iC].y = aInsdCl[iC][1];
		pCld->points[iC].z = aInsdCl[iC][2];
	}
	KdTr.setInputCloud(pCld);

	//If aOtsdCl[i] is inside aInsdCl
	for (int iC = 0; iC < aOtsdCl.size(); ++iC)
	{
		vector<double>& vOtCl = aOtsdCl[iC];
		double aOrnt[3] = { vOtCl[0] - vInsdCntr[0], vOtCl[1] - vInsdCntr[1], vOtCl[2] - vInsdCntr[2] };
		double fOrntNrm = sqrt(aOrnt[0] * aOrnt[0] + aOrnt[1] * aOrnt[1] + aOrnt[2] * aOrnt[2]);
		aOrnt[0] = aOrnt[0] / fOrntNrm; aOrnt[1] = aOrnt[1] / fOrntNrm; aOrnt[2] = aOrnt[2] / fOrntNrm; //��λ��
		//KD Tree
		pcl::PointXYZ PntCntr; 
		int iK = 3;
		pcl::Indices IndxNr; 
		std::vector<float> vRdsNr;
		PntCntr.x = vInsdCntr[0] + 40.0 * aOrnt[0];
		PntCntr.y = vInsdCntr[1] + 40.0 * aOrnt[1];
		PntCntr.z = vInsdCntr[2] + 40.0 * aOrnt[2];
		KdTr.nearestKSearch(PntCntr, iK, IndxNr, vRdsNr);
		double vNr[3] = { 0.0,0.0,0.0 };
		for (int iNr = 0; iNr < IndxNr.size(); ++iNr)
		{
			int jS = IndxNr[iNr];
			double vNrOrnt[3] = { pCld->points[jS].x - vInsdCntr[0], pCld->points[jS].y - vInsdCntr[1], pCld->points[jS].z - vInsdCntr[2] };
			double fNrOrntNrm = sqrt(vNrOrnt[0] * vNrOrnt[0] + vNrOrnt[1] * vNrOrnt[1] + vNrOrnt[2] * vNrOrnt[2]);
			vNrOrnt[0] = vNrOrnt[0] / fNrOrntNrm; vNrOrnt[1] = vNrOrnt[1] / fNrOrntNrm; vNrOrnt[2] = vNrOrnt[2] / fNrOrntNrm; //��λ��
			vNr[0] += vInsdCntr[0] + vNrOrnt[0] * (fNrOrntNrm + 6.7);
			vNr[1] += vInsdCntr[1] + vNrOrnt[1] * (fNrOrntNrm + 6.7);
			vNr[2] += vInsdCntr[2] + vNrOrnt[2] * (fNrOrntNrm + 6.7);
		}
		
		double fInsdRds = ((vNr[0] - 3.0 * vInsdCntr[0]) * aOrnt[0] + (vNr[1] - 3.0 * vInsdCntr[1]) * aOrnt[1] + (vNr[2] - 3.0 * vInsdCntr[2]) * aOrnt[2]) / 3.0;
		
		if (fOrntNrm < fInsdRds) //Trapped in the inside cell clusters
		{
			++iTrpAmnt;
		}
	}
	/////Variable finish
	/////Normal end
	//aOtsdCl.size() == iTrpAmnt, fSrtIndx=0, iTrpAmnt==0, fSrtIndx=1
	double fSrtIndx = ((double)(aOtsdCl.size() - iTrpAmnt)) / ((double)aOtsdCl.size());
	return fSrtIndx;
}

//Calculate cell morphology index
bool CEmbry::Mrphlgy()
{
	//////Safe
	//////Varialbe define
	std::vector<double>& aT = CSCE::aT();
	std::vector<CCl>& aCl = m_aCl;
	int iLngAmnt = 25;
	int iLtAmnt = 36;
	int iVrtxAmntInCl = (iLngAmnt - 2) * iLtAmnt + 2;
	std::vector<CSCE>& aSCE = *m_pSCEAry;
	long iFrmBgn = 0; // 0.5 * aSCE[0].aP().size();
	long iFrmAmnt = aSCE[0].aP().size() - iFrmBgn;
	std::cout << "Frames: " << iFrmBgn << ", " << iFrmAmnt << "\n";
	std::vector<std::vector<std::vector<double>>> aClCntr(aCl.size());// aCntr[iC][iFrm] = iC's cell center at a frame
	std::vector<std::vector<double>> aClRds(aCl.size());// aClRds[iC][iFrm] = iC's cell radius at a frame
	//////Process
	for (long iC = 0; iC < aCl.size(); ++iC)
	{
		std::vector<double> aShpIndx; //Shape index at a frame
		double fAvrgShpIndx(0.0);
		double fSDShpIndx(0.0);
		std::vector<std::vector<double>> aVrxtRds(iVrtxAmntInCl); //aVrxtRds[iV][iFrm] = vertex-center distance
		for (long iFrm = iFrmBgn; iFrm < aSCE[0].aP().size(); ++iFrm)
		{
			std::vector<double> vCntr;
			double fClRds(0.0);
			std::vector<std::vector<double>> aSrfcVrtx;
			double fShpIndx = aCl[iC].GtMrphlgy(vCntr, fClRds, aSrfcVrtx, iFrm, iLngAmnt, iLtAmnt);
			//Shape index average of time
			aShpIndx.push_back(fShpIndx);
			fAvrgShpIndx += fShpIndx;
			//Surface fluc
			for (int iV = 0; iV < iVrtxAmntInCl; ++iV)
			{
				std::vector<double>& vVrtx = aSrfcVrtx[iV];
				double fVrxtRds = sqrt(pow(vVrtx[0] - vCntr[0], 2) + pow(vVrtx[1] - vCntr[1], 2) + pow(vVrtx[2] - vCntr[2], 2));
				aVrxtRds[iV].push_back(fVrxtRds);
			}
			//Affnity
			aClCntr[iC].push_back(vCntr);
			aClRds[iC].push_back(fClRds);
		}
		//Shape index average of time
		fAvrgShpIndx = fAvrgShpIndx / ((double)aShpIndx.size());
		for (long iFrm = 0; iFrm < aShpIndx.size(); ++iFrm)
		{
			fSDShpIndx += pow(aShpIndx[iFrm] - fAvrgShpIndx, 2);
		}
		fSDShpIndx = sqrt( fSDShpIndx /((double)aShpIndx.size()) );
		std::cout << "Cell = " << iC << ", ";
		std::cout << "Shape index = " << fAvrgShpIndx <<", Variation coefficient = " << fSDShpIndx/fAvrgShpIndx<< ", ";
		//std::cout << "Shape index = " << fAvrgShpIndx << ", SD = " << fSDShpIndx << ", Variation coefficient = " << fSDShpIndx / fAvrgShpIndx << ", ";

		//Surface fluc
		double fFlc(0.0); 
		double fVrxtRds_Debug(0.0); 
		for (int iV = 0; iV < iVrtxAmntInCl; ++iV)
		{
			double fAvrgVrtxRds(0.0), fSDVrtxRds(0.0);
			for (int iFrm = 0; iFrm < aVrxtRds[iV].size(); ++iFrm) //Average of vertex-center distance
			{
				fAvrgVrtxRds += aVrxtRds[iV][iFrm];
			}
			fAvrgVrtxRds = fAvrgVrtxRds / ((double)aVrxtRds[iV].size());
			fVrxtRds_Debug += fAvrgVrtxRds;
			for (int iFrm = 0; iFrm < aVrxtRds[iV].size(); ++iFrm) //SD of vertex-center distance
			{
				fSDVrtxRds += pow(aVrxtRds[iV][iFrm] - fAvrgVrtxRds, 2);
			}
			fSDVrtxRds = sqrt(fSDVrtxRds / ((double)aVrxtRds[iV].size()));
			fFlc += fSDVrtxRds;
		}
		fFlc = fFlc / ((double)iVrtxAmntInCl); //Cell's Fluctuation Index
		fVrxtRds_Debug = fVrxtRds_Debug / ((double)iVrtxAmntInCl); //Debug
		std::cout << "Fluc = " << fFlc << ", ";
		////Debug
		//{
		//	double fClRds_Debug(0.0);
		//	for (long iFrm = 0; iFrm < aClRds[iC].size(); ++iFrm)
		//	{
		//		fClRds_Debug += aClRds[iC][iFrm];
		//	}
		//	fClRds_Debug = fClRds_Debug / ((double)aClRds[iC].size());
		//	std::cout << "Cell R (Vrtx) = " << fVrxtRds_Debug << ", Cell R (Cell) = " << fClRds_Debug <<", ";
		//}
		std::cout <<"\n";
	}

	//Affinity
	if (aCl.size() == 2)
	{
		int iFrmAmnt(0.0);
		double fAvrgCntrDstnc(0.0); //average cell center distance
		double fAvrgClRdsA(0.0), fAvrgClRdsB(0.0); //average radius of two cells
		for (long iFrm = 0; iFrm < aClCntr[0].size(); ++iFrm)
		{
			std::vector<double>& vCA = aClCntr[0][iFrm];
			std::vector<double>& vCB = aClCntr[1][iFrm];
			double fCntrDstnc = sqrt(pow(vCA[0] - vCB[0], 2) + pow(vCA[1] - vCB[1], 2) + pow(vCA[2] - vCB[2], 2));
			double fClRdsA = aClRds[0][iFrm];
			double fClRdsB = aClRds[1][iFrm];
			if (fCntrDstnc < (fClRdsA + fClRdsB))
			{
				fAvrgCntrDstnc += fCntrDstnc;
				fAvrgClRdsA += fClRdsA;
				fAvrgClRdsB += fClRdsB;
				++iFrmAmnt;
			}			
		}
		fAvrgCntrDstnc = fAvrgCntrDstnc / ((double)iFrmAmnt);
		fAvrgClRdsA = fAvrgClRdsA / ((double)iFrmAmnt);
		fAvrgClRdsB = fAvrgClRdsB / ((double)iFrmAmnt);
		
		double fAvrgSmPrmtr = 0.5 * (fAvrgCntrDstnc + fAvrgClRdsA + fAvrgClRdsB); //Semi-Perimeter
		double fAvrgChrd = 4 * sqrt(fAvrgSmPrmtr * (fAvrgSmPrmtr - fAvrgCntrDstnc) * (fAvrgSmPrmtr - fAvrgClRdsA) * (fAvrgSmPrmtr - fAvrgClRdsB)) / fAvrgCntrDstnc;
		std::cout << "Affinity (Cell) = " << fAvrgChrd/(fAvrgCntrDstnc+fAvrgClRdsA+fAvrgClRdsB) <<"\n";
	}

	/////Variable finish
	/////Normal end
	return true;
}

//Export Cell distacne & contact (SCE amount contacted)
bool CEmbry::ExprtClRltn(const string& sPthDstnc, const string& sPthCntct, const long& iFrm)
{
	//////Safe
	//////Varialbe define
	std::vector<CCl>& aCl = m_aCl;
	std::vector<CSCE>& aSCE = *m_pSCEAry;
	std::vector<std::vector<double>> aClCntr(aCl.size()); 
	std::fstream fCsvDstnc(sPthDstnc, std::ios::out);
	std::fstream fCsvCntct(sPthCntct, std::ios::out);
	/////Process

	for (int iC = 0; iC < aCl.size(); ++iC)
	{
		aCl[iC].GtCntr(aClCntr[iC], iFrm);
	}

	//Export
	if ((fCsvDstnc.is_open()) && (fCsvCntct.is_open()))
	{
		//Line 0, Cell Index
		fCsvDstnc << "Cell Index";
		fCsvCntct << "Cell Index";
		for (int iC = 0; iC < aCl.size(); ++iC)
		{
			fCsvDstnc << ",";
			fCsvDstnc << "Cell_" << iC;
			fCsvCntct << ",";
			fCsvCntct << "Cell_" << iC;
		}
		fCsvDstnc << "\n";
		fCsvCntct << "\n";
		//Data lines
		for (int iC = 0; iC < aCl.size(); ++iC)
		{
			fCsvDstnc << "Cell_" << iC;
			fCsvCntct << "Cell_" << iC;
			for (int jC = 0; jC < aCl.size(); ++jC)
			{
				//fCsvDstnc
				std::vector<double>& vCntrA = aClCntr[iC];
				std::vector<double>& vCntrB = aClCntr[jC];
				double fDstnc = sqrt(pow(vCntrA[0] - vCntrB[0], 2) + pow(vCntrA[1] - vCntrB[1], 2) + pow(vCntrA[2] - vCntrB[2], 2));
				fCsvDstnc << ",";
				fCsvDstnc << fDstnc;
				//fCsvCntct
				fCsvCntct << ",";
				fCsvCntct << CntctSCE(iC, jC, iFrm);
			}
			fCsvDstnc << "\n";
			fCsvCntct << "\n";
		}
	}
	fCsvDstnc.close();
	fCsvCntct.close();
	/////Variable finish
	/////Normal end
	return true;
}

//Return Cell contace SCE amouunt,
double CEmbry::CntctSCE(const int& iClA, const int& iClB, const long& iFrm)
{
	//////Safe
	if (iClA == iClB) return 0.0;
	//////Varialbe define
	std::vector<CCl>& aCl = m_aCl;
	std::vector<CSCE>& aSCE = *m_pSCEAry;
	double fCntctShrshld = CSCE::REq(); //<=fCntctShrshld is contact SCE
	long iCntctSCEA(0), iCntctSCEB(0);
	//PCL, KD Tree
	pcl::PointCloud<pcl::PointXYZ>::Ptr pCld(new pcl::PointCloud<pcl::PointXYZ>);
	pcl::KdTreeFLANN<pcl::PointXYZ> KdTr;
	/////Process
	///CellB SCE Tree, 
	pCld->width = aCl[iClB].SCETl() - aCl[iClB].SCEHd() + 1;
	pCld->height = 1;
	pCld->resize(pCld->width * pCld->height);
	for (int iS = 0; iS < pCld->width; ++iS)
	{
		CSCE& SCE = aSCE[iS + aCl[iClB].SCEHd()];
		pCld->points[iS].x = SCE.aP()[iFrm][0];
		pCld->points[iS].y = SCE.aP()[iFrm][1];
		pCld->points[iS].z = SCE.aP()[iFrm][2];
	}
	KdTr.setInputCloud(pCld);
	//
	for (int iS = aCl[iClA].SCEHd(); iS <= aCl[iClA].SCETl(); ++iS)
	{
		CSCE& SCE = aSCE[iS];
		std::vector<double>& vP = SCE.aP()[iFrm];
		pcl::PointXYZ PntCntr;
		int iK = 1;
		pcl::Indices IndxNr;
		std::vector<float> vRdsNr;
		PntCntr.x = vP[0];
		PntCntr.y = vP[1];
		PntCntr.z = vP[2];
		KdTr.nearestKSearch(PntCntr, iK, IndxNr, vRdsNr);
		int jS = IndxNr[0];
		double vNr[3] = { pCld->points[jS].x, pCld->points[jS].y, pCld->points[jS].z };
		double fDstnc = sqrt(pow(vP[0] - vNr[0], 2) + pow(vP[1] - vNr[1], 2) + pow(vP[2] - vNr[2], 2));
		if (fDstnc <= fCntctShrshld)
		{
			++iCntctSCEA;
			//Debug
			//SCE.Typ() = 2;
		}
	}

	///CellA SCE Tree, 
	pCld->width = aCl[iClA].SCETl() - aCl[iClA].SCEHd() + 1;
	pCld->height = 1;
	pCld->resize(pCld->width * pCld->height);
	for (int iS = 0; iS < pCld->width; ++iS)
	{
		CSCE& SCE = aSCE[iS + aCl[iClA].SCEHd()];
		pCld->points[iS].x = SCE.aP()[iFrm][0];
		pCld->points[iS].y = SCE.aP()[iFrm][1];
		pCld->points[iS].z = SCE.aP()[iFrm][2];
	}
	KdTr.setInputCloud(pCld);
	
	for (int iS = aCl[iClB].SCEHd(); iS <= aCl[iClB].SCETl(); ++iS)
	{
		CSCE& SCE = aSCE[iS];
		std::vector<double>& vP = SCE.aP()[iFrm];
		pcl::PointXYZ PntCntr;
		int iK = 1;
		pcl::Indices IndxNr;
		std::vector<float> vRdsNr;
		PntCntr.x = vP[0];
		PntCntr.y = vP[1];
		PntCntr.z = vP[2];
		KdTr.nearestKSearch(PntCntr, iK, IndxNr, vRdsNr);
		int jS = IndxNr[0];
		double vNr[3] = { pCld->points[jS].x, pCld->points[jS].y, pCld->points[jS].z };
		double fDstnc = sqrt(pow(vP[0] - vNr[0], 2) + pow(vP[1] - vNr[1], 2) + pow(vP[2] - vNr[2], 2));
		if (fDstnc <= fCntctShrshld)
		{
			++iCntctSCEB;
			//Debug
			//SCE.Typ() = 2;
		}
	}
	/////Variable finish
	//std::cout<<"iCntctSCE A,B = "<< iCntctSCEA<<", "<< iCntctSCEB<<"\n";
	/////Normal end
	return 0.5 * (double)(iCntctSCEA + iCntctSCEB);
}

vector<string> Split(string sLn, char cDvd)
{
	std::stringstream ssLn(sLn);
	string sDt;
	vector<string> aDt;
	while (getline(ssLn, sDt, cDvd))
	{
		aDt.push_back(sDt);
	}
	return aDt;
}