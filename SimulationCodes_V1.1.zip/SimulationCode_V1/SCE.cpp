﻿#include "SCE.h"
#include "Embry.h"

//////Static
vector<double> CSCE::m_aT;

//PCL point cloud and KD Tree
pcl::PointCloud<pcl::PointXYZ>::Ptr CSCE::m_pCld(new pcl::PointCloud<pcl::PointXYZ>);
pcl::KdTreeFLANN<pcl::PointXYZ> CSCE::m_KdTr;

//Morse potential parameters [Modeling cell rheology with the Subcellular Element Model]
double CSCE::m_fREq; //REq
double CSCE::m_fRou; //ρ
double CSCE::m_fU0; //Potential well depth
double CSCE::m_fK; //stiffness
double CSCE::m_fCntctFctr; //Contact factors
double CSCE::m_fAfntyFctr_Intr; //Atrractive factor, intra-Cell
double CSCE::m_fAfntyFctr_00; //Atrractive factor, Inter-Cell, Type0-0
double CSCE::m_fAfntyFctr_01; //Atrractive factor, Inter-Cell, Type0-1 & 1-2
double CSCE::m_fAfntyFctr_11; //Atrractive factor, Inter-Cell, Type1-1
double CSCE::m_fAfntyFctr_0B; //Atrractive factor, Inter-Cell, Cell Type0 - TE
double CSCE::m_fAfntyFctr_1B; //Atrractive factor, Inter-Cell, Cell Type1 - TE

//Random variables
std::default_random_engine CSCE::m_RndmEngn;
std::normal_distribution<double> CSCE::m_GsnDstrbt(0, 1);
std::uniform_real_distribution<double> CSCE::m_UnfrmDstrbt(0, 6.28);

//Intial Morse potential parameters. fClDmtr is Cell Diameter, iSCEAmntInCl is the amount of SCE per cell
bool CSCE::IntlMrsPtntlPrm(const double& fClDmtr, const int& iSCEAmntInCl)
{
	//////Safe

	//////Varialbe define
	double fP3 = 0.7405; //Packing density of SCE in cube. //0.64;//Packing density of SCE in sphere
	double fK0 = 5.0; //5e-3[N/m] = 5 [[F]/[L]]
	double fLmd = 0.75; //λ

	//////Process
	CSCE::m_fREq = fClDmtr * cbrt(fP3 / ((double)iSCEAmntInCl)); //REq in literature
	CSCE::m_fK = fK0 * (1.0 - fLmd / cbrt((double)iSCEAmntInCl)) / cbrt((double)iSCEAmntInCl);
	CSCE::m_fRou = 2.0; // 4.0;
	CSCE::m_fU0 = m_fK * m_fREq * m_fREq / (8.0 * m_fRou * m_fRou);

	CSCE::m_fCntctFctr = 1.0;
	CSCE::m_fAfntyFctr_Intr = 1.0;
	CSCE::m_fAfntyFctr_00 = 0.0;
	CSCE::m_fAfntyFctr_01 = 0.0;
	CSCE::m_fAfntyFctr_11 = 0.0; 
	CSCE::m_fAfntyFctr_0B = 0.0;
	CSCE::m_fAfntyFctr_1B = 0.0;
	/////Variable finish
	/////Normal end
	return true;
}

bool CSCE::IntlPclKdTr(vector<CSCE>& aSCE)
{
	//////Safe
	//////Varialbe define
	CSCE::m_pCld->width = aSCE.size();
	m_pCld->height = 1;
	m_pCld->resize(m_pCld->width * m_pCld->height);
	//////Process
	/////Variable finish
	/////Normal end
	return true;
}

//Run. Calculate all SCE.m_cP/V according to initial value and external force by iterate
bool CSCE::Run(vector<CSCE>& aSCE, const double& fDt)
{
	//////Safe
	for (long iS = 0; iS < aSCE.size(); ++iS)
	{
		CSCE& SCE = aSCE[iS];
		
		for (; SCE.aP().size() > 1;) 
		{ 
			SCE.aP().pop_back();
			SCE.aV().pop_back();
		}
	}
	//////Varialbe define
	vector<double>& aT = CSCE::aT();
	double fMxT = aT[aT.size() - 1];
	long iFrm(1);
	vector<double> aX(aSCE.size() * 3); //CX'(t) = F(X,t) + ξ(t)
	vector<double> aXNxt(aSCE.size() * 3); //aXNxt is calculated from aX via  Itrt_RK()
	vector<double> aBNxt(aSCE.size() * 3); //Random displacement at each step
	//////Process
	//X0
	for (long iS = 0; iS < aSCE.size(); ++iS)
	{
		CSCE& SCE = aSCE[iS];
		aX[iS*3 + 0] = SCE.aP()[0][0];
		aX[iS*3 + 1] = SCE.aP()[0][1];
		aX[iS*3 + 2] = SCE.aP()[0][2];
	}
	//X1->XN
	for (double fT = aT[0] + fDt; (fT < (fMxT + fDt)) && (iFrm < aT.size()); fT += fDt)
	{
		//X(t) = A(t) + B(t)
		//Let A(n) = X(n) => A(n+1)
		Itrt_RK(aX, fT, fDt, F, aXNxt);
		//let B(n)总是=0 => B(n+1)
		Itrt_Brwn(aXNxt, fT, fDt, aBNxt);

		//Update SCE.m_cP/V/[].
		if ((aT[iFrm] <= fT) && (fT < (aT[iFrm] + fDt))) //if fT is within aT[iFrm]
		{
			for (long iS = 0; iS < aSCE.size(); ++iS)
			{
				CSCE& SCE = aSCE[iS];
				vector<double> vRslt(3);
				//P(t)
				vRslt[0] = aX[iS*3 + 0];
				vRslt[1] = aX[iS*3 + 1];
				vRslt[2] = aX[iS*3 + 2];
				SCE.aP().push_back(vRslt);
				//V(t) = [ -P(t-△t) + P(t) ] / (△t) 
				vRslt[0] = (aXNxt[iS*3+0] + aBNxt[iS*3+0] - aX[iS*3+0])/fDt;
				vRslt[1] = (aXNxt[iS*3+1] + aBNxt[iS*3+1] - aX[iS*3+1])/fDt;
				vRslt[2] = (aXNxt[iS*3+2] + aBNxt[iS*3+2] - aX[iS*3+2])/fDt;
				SCE.aV().push_back(vRslt);
				
			}
			++iFrm;
			//{Debug
			std::cout << "Frame: " << iFrm << ",\t" << "T: " << fT << ",\t"<<fT*100/fMxT<<"%\n";
			//}Debug
		}

		//最终的X(n+1) = A(n+1) + B(n+1), 并赋值给X(n)准备下一次迭代
		for (long i = 0; i < aX.size(); ++i)
		{
			aX[i] = aXNxt[i] + aBNxt[i];
		}
	}

	/////Variable finish

	/////Normal end
	return true;
}

//////Non Static
CSCE::CSCE(const double& fC, const long& iCl, const int& iTyp, const double& fP0_x, const double& fP0_y, const double& fP0_z, const double& fV0_x, const double& fV0_y, const double& fV0_z)
{
	//////Safe
	//////Varialbe define
	//////Process
	m_fC = fC;
	m_iCl = iCl;
	m_iTyp = iTyp;
	//m_fPhs
	m_fPhs = m_UnfrmDstrbt(m_RndmEngn);
	//std::cout << m_fPhs << "\n";
	//
	vector<double> aP0(3); aP0[0] = fP0_x; aP0[1] = fP0_y; aP0[2] = fP0_z;
	m_aP.push_back(aP0);
	vector<double> aV0(3); aV0[0] = fV0_x; aV0[1] = fV0_y; aV0[2] = fV0_z;
	m_aV.push_back(aV0);
	/////Variable finish
	/////Normal end
}

//IsZero
bool IsZr(const double& fDt)
{
	//////Safe
	//////Varialbe define
	//////Process
	/////Variable finish
	/////Normal end
	if ((fDt > -1.0e-6) && (fDt < 1.0e-6))
	{
		return true;
	}
	else
	{
		return false;
	}
}

//Itrt_RK, Order 4 Runge-Kutta
//Y'=F(Y,x), Y', Y, F is vectors, x is fT
//YNxt = Y + (K1 + 2K2 + 2K3 + K4)*h/6
//K1 = F(Y,x); K2 = F(Y+0.5hK1, x+0.5h); K3 = F(Y+0.5hK2, x+0.5h), K4 = F(Y+hK3, x+h)
bool Itrt_RK(vector<double>& aY, double& fX, const double& fH, bool (*pF)(vector<double>& aF, vector<double>& aY, double fX), vector<double>& aYNxt)
{
	//////Safe
	//////Varialbe define
	vector<CSCE>& aSCE = *(CEmbry::GtSCEAry());
	long iSCEAmnt = aSCE.size(); //(aY.Amnt()) / 3;
	long iDmnsn = aY.size();
	vector<double> aYTmp(iDmnsn); //temperary restore values
	vector<double> aK1(iDmnsn), aK2(iDmnsn), aK3(iDmnsn), aK4(iDmnsn); //K1/2/3/4,
	//////Process
	// //准备KT Tree_Mark
	
	//K1
	(*pF)(aK1, aY, fX); //K1 = F(Y,x)
	//K2
	for (long iD = 0; iD < iDmnsn; ++iD)
	{
		aYTmp[iD] = aY[iD] + 0.5 * fH * aK1[iD]; //Y+0.5hK1
	}
	(*pF)(aK2, aYTmp, fX + 0.5 * fH); //K2 = F(Y+0.5hK1, x+0.5h)
	//K3
	for (long iD = 0; iD < iDmnsn; ++iD)
	{
		aYTmp[iD] = aY[iD] + 0.5 * fH * aK2[iD]; //Y+0.5hK2
	}
	(*pF)(aK3, aYTmp, fX + 0.5 * fH); //K3 = F(Y+0.5hK2, x+0.5h)
	//K4
	for (long iD = 0; iD < iDmnsn; ++iD)
	{
		aYTmp[iD] = aY[iD] + fH * aK3[iD]; //Y+hK3
	}
	(*pF)(aK4, aYTmp, fX + fH); //K4 = F(Y+hK3, x+h)
	//YNxt = Y + (K1 + 2K2 + 2K3 + K4)*h/6
	for (long iD = 0; iD < iDmnsn; ++iD)
	{
		aYNxt[iD] = aY[iD] + ((aK1[iD] + 2.0 * aK2[iD] + 2.0 * aK3[iD] + aK4[iD]) * fH / 6.0);
	}
	//////Normal End
	return true;
}

//The F() in Itrt_RK()
//F= ( ∑F(Pi,Pj) + FGaussian(t) )/fC, //fC is damping in Langevin equation: fC * Y' = ∑F(Pi,Pj) + FGaussian(t)
bool F(vector<double>& aF, vector<double>& aY, double fX)
{
	//////Safe
	for (int iF = 0; iF < aF.size(); ++iF)
	{
		aF[iF] = 0.0;
	}
	//////Varialbe define
	vector<CSCE>& aSCE = *(CEmbry::GtSCEAry());
	long iSCEAmnt = aSCE.size(); //(aY.Amnt()) / 3;
	double fSrchRads = 2.5 * CSCE::REq(); //2.0 * CSCE::REq(); 
	double fEmbryRds = 0.5 * CEmbry::Dmtr_AdHld(fX); //Diameter of blastocyst at time fX
	double fPhs = (6.28 * fX / 150.0);
	double fEPIFlc = 0.1; //EPI fluctuation factor
	double fEPIStf = 1.0; //EPI stiffness factor
	double fPrEFlc = 0.6; //PrE fluctuation factor
	double fPrEStf = 0.95; //PrE stiffness factor
	//////Process
	//KT Tree
	for (long iS = 0; iS < iSCEAmnt; ++iS)
	{
		CSCE::pCld()->points[iS].x = aY[iS * 3 + 0];
		CSCE::pCld()->points[iS].y = aY[iS * 3 + 1];
		CSCE::pCld()->points[iS].z = aY[iS * 3 + 2];
	}
	CSCE::KdTr().setInputCloud(CSCE::pCld());
	//calculate aF for every SCE
#pragma omp parallel for
	for (long iS = 0; iS < iSCEAmnt; ++iS)
	{
		
		double fCntctFctr(0), fAfntyFctr(0);
		double& fPx = aY[iS * 3 + 0];
		double& fPy = aY[iS * 3 + 1];
		double& fPz = aY[iS * 3 + 2];
		CSCE& SCE = aSCE[iS];
		double fREqFlc(0.0);

		pcl::PointXYZ PntCntr;
		pcl::Indices IndxNr;
		std::vector<float> vRdsNr;
		PntCntr.x = fPx;
		PntCntr.y = fPy;
		PntCntr.z = fPz;
		CSCE::KdTr().radiusSearch(PntCntr, fSrchRads, IndxNr, vRdsNr);
		//Calculate interactions between cSCE[iS] and neighbour SCEs, add into aF[iS*3+0/1/2]
		//cout << IndxNr.size() << "\n";
		for (int iNr = 0; iNr < IndxNr.size(); ++iNr)
		{
			int jS = IndxNr[iNr];
			
			double& fPNrx = aY[jS * 3 + 0];
			double& fPNry = aY[jS * 3 + 1];
			double& fPNrz = aY[jS * 3 + 2];
			if (jS != iS)
			{
				if (SCE.Cl() == aSCE[jS].Cl()) //Intra Cell
				{ 
					if (SCE.Typ() == 0) //PrE
					{
						fCntctFctr = fPrEStf *CSCE::CntctFctr(); fAfntyFctr = fPrEStf *CSCE::AfntyFctr_Intr();
						fREqFlc = CSCE::REq() * std::max(1.0 + fPrEFlc * sin(fPhs + SCE.Phs() + aSCE[jS].Phs()), 0.0);
					}
					else if (SCE.Typ() == 1) //EPI
					{
						fCntctFctr = fEPIStf*CSCE::CntctFctr(); fAfntyFctr = fEPIStf * CSCE::AfntyFctr_Intr();
						fREqFlc = CSCE::REq() *std::max(1.0 + fEPIFlc * sin(fPhs + SCE.Phs() + aSCE[jS].Phs()), 0.0);
					}
				}
				else //Inter cell
				{
					fREqFlc = CSCE::REq();
					if ((SCE.Typ() == 0) && (aSCE[jS].Typ() == 0)) { fCntctFctr = CSCE::CntctFctr(); fAfntyFctr = CSCE::AfntyFctr_00(); } //0.2; } //Inter Cell 0-0
					else if ((SCE.Typ() == 0) && (aSCE[jS].Typ() == 1)) { fCntctFctr = CSCE::CntctFctr(); fAfntyFctr = CSCE::AfntyFctr_01(); } //Inter Cell 0-1
					else if ((SCE.Typ() == 1) && (aSCE[jS].Typ() == 0)) { fCntctFctr = CSCE::CntctFctr(); fAfntyFctr = CSCE::AfntyFctr_01(); } //Inter Cell 1-0
					else if ((SCE.Typ() == 1) && (aSCE[jS].Typ() == 1)) { fCntctFctr = CSCE::CntctFctr(); fAfntyFctr = CSCE::AfntyFctr_11(); } //0.08; } //Inter Cell 1-1
					else { fCntctFctr = 1.0; fAfntyFctr = 0.0; }
				}
				double fFx(0.0), fFy(0.0), fFz(0.0);
				//CSCE::Intrct(fFx, fFy, fFz, fPNrx, fPNry, fPNrz, fPx, fPy, fPz, fCntctFctr, fAfntyFctr);
				CSCE::Intrct(fFx, fFy, fFz, fPNrx, fPNry, fPNrz, fPx, fPy, fPz, fCntctFctr, fAfntyFctr, fREqFlc);
				aF[iS * 3 + 0] += fFx;
				aF[iS * 3 + 1] += fFy;
				aF[iS * 3 + 2] += fFz;
			}
		}
		//Calculate the interaction bwtween TE (fPBndx/y/z) and cSCE[iS], add into aF[iS*3+0/1/2]
		if (CEmbry::TE()) ////If ICM in trophectoderm
		{
			double fP = sqrt((fPx * fPx) + (fPy * fPy) + (fPz * fPz)); //Distance between SCE and blastocyst center
			if ((fEmbryRds > fP) && (fP > (fEmbryRds - fSrchRads)))
			{
				if (SCE.Typ() == 0) { fCntctFctr = CSCE::CntctFctr(); fAfntyFctr = CSCE::AfntyFctr_0B(); }
				else { fCntctFctr = CSCE::CntctFctr(); fAfntyFctr = CSCE::AfntyFctr_1B(); }

				//Force of nearest equivalent SCE of TE on SCE[iS]
				double fPBndx = fEmbryRds * fPx / fP;
				double fPBndy = fEmbryRds * fPy / fP; 
				double fPBndz = fEmbryRds * fPz / fP; 
				double fFx(0.0), fFy(0.0), fFz(0.0);				
				CSCE::Intrct(fFx, fFy, fFz, fPBndx, fPBndy, fPBndz, fPx, fPy, fPz, fCntctFctr, fAfntyFctr);
				aF[iS * 3 + 0] += fFx;
				aF[iS * 3 + 1] += fFy;
				aF[iS * 3 + 2] += fFz;

				//Force of the second nearest equivalent SCEs of TE on SCE[iS]
				double fDstncEq = sqrt(pow(fEmbryRds - fP, 2) + CSCE::REq() * CSCE::REq());
				fPBndx = (fP + fDstncEq) * fPx / fP;
				fPBndy = (fP + fDstncEq) * fPy / fP;
				fPBndz = (fP + fDstncEq) * fPz / fP;
				CSCE::Intrct(fFx, fFy, fFz, fPBndx, fPBndy, fPBndz, fPx, fPy, fPz, fCntctFctr, fAfntyFctr);
				aF[iS * 3 + 0] += fFx * 4.0 * (fEmbryRds - fP) / fDstncEq;
				aF[iS * 3 + 1] += fFy * 4.0 * (fEmbryRds - fP) / fDstncEq;
				aF[iS * 3 + 2] += fFz * 4.0 * (fEmbryRds - fP) / fDstncEq;
				}
		}
		//External force for the development of initial condition , not used after fT>=0
		{
			////F = CV
			double fV = -0.8; //[um/s]
			double fG = fV * aSCE[iS].C();
			double fT1 = -240.0;
			double fT2 = -180.0;
			if (fX < fT1)
			{
				aF[iS * 3 + 1] += fG;
			}
			else if ((fT1 <= fX) && (fX < fT2))
			{
				aF[iS * 3 + 1] += (fT2 - fX) * fG / (fT2 - fT1);
			}
			else
			{
				//aF[iS * 3 + 1] +=0
			}
		}
	}
	//F= ( ∑F(Pi,Pj) + FGaussian(t) )/fC. 
	for (long iS = 0; iS < iSCEAmnt; ++iS)
	{
		aF[iS * 3 + 0] = aF[iS * 3 + 0] / aSCE[iS].C();
		aF[iS * 3 + 1] = aF[iS * 3 + 1] / aSCE[iS].C();
		aF[iS * 3 + 2] = aF[iS * 3 + 2] / aSCE[iS].C();
	}
	//////Normal End
	return true;
}

//SCE Interaction force, calculate the force of PA to PB
//V(R) = U0 * [( exp(ρ(1-R^2/Req^2))-1 )^2 -1], =>
//F = - dV/dR = U0 * 4*ρ*[ exp(ρ(1-R^2/Req^2))-1 ] * exp(ρ(1-R^2/Req^2)) * ( R/Req^2 ),
//F(P,PNr) = U0 * 4*ρ*[ exp(ρ(1-R^2/Req^2))-1 ] * exp(ρ(1-R^2/Req^2)) * (P-PNr)/Req^2
//R^2 = Rx^2 + Ry^2 + Rz^2
//Fx = -∂V/∂Rx = U0 * 4*ρ*[ exp(ρ(1-R^2/Req^2))-1 ] * exp(ρ(1-R^2/Req^2)) * ( Rx/Req^2 ) //Fy & Fz similar
//Fx(Px,PNrx) = U0 * 4*ρ*[ exp(ρ(1-R^2/Req^2))-1 ] * exp(ρ(1-R^2/Req^2)) * (Px-PNrx)/Req^2 
//Let CF = exp(ρ(1-R^2/Req^2)) = exp(ρ(1 - Rx^2/Req^2 - Ry^2/Req^2 - Rz^2/Req^2) = exp(ρ(1 - (Rx^2+Ry^2+Rz^2-PNrx^2-PNry^2-PNrz^2)/Req^2))
bool CSCE::Intrct(double& fFx, double& fFy, double& fFz, double& fPAx, double& fPAy, double& fPAz, double& fPBx, double& fPBy, double& fPBz, const double& fCntctFctr, const double& fAfntyFctr)
{
	//////Safe
	//////Varialbe define
	double fRx = fPBx - fPAx; 
	double fRy = fPBy - fPAy;
	double fRz = fPBz - fPAz;
	double fR = sqrt((fRx * fRx) + (fRy * fRy) + (fRz * fRz));
	double fREqSqr = CSCE::REq() * CSCE::REq();
	double fCf = exp(m_fRou * (1.0 - (fR * fR / fREqSqr)));
	//////Process
	if (!IsZr(fR))
	{
		if (fR < m_fREq) //Contact.
		{
			fFx = fCntctFctr * fRx * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
			fFy = fCntctFctr * fRy * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
			fFz = fCntctFctr * fRz * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
		}
		else if (m_fREq < fR) //Attractive
		{
			fFx = fAfntyFctr * fRx * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
			fFy = fAfntyFctr * fRy * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
			fFz = fAfntyFctr * fRz * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
		}
		else //fR==fREq
		{			
			fFx = 0.0;
			fFy = 0.0;
			fFz = 0.0;
		}
	}
	/////Variable finish
	/////Normal end
	return true;
}

///Change fREq version of Intrct()
bool CSCE::Intrct(double& fFx, double& fFy, double& fFz, double& fPAx, double& fPAy, double& fPAz, double& fPBx, double& fPBy, double& fPBz, const double& fCntctFctr, const double& fAfntyFctr, const double& fREqFlc)
{
	//////Safe
	//////Varialbe define
	double fRx = fPBx - fPAx;
	double fRy = fPBy - fPAy;
	double fRz = fPBz - fPAz;
	double fR = sqrt((fRx * fRx) + (fRy * fRy) + (fRz * fRz));
	double fREqSqr = fREqFlc * fREqFlc;
	double fCf = exp(m_fRou * (1.0 - (fR * fR / fREqSqr)));
	//////Process
	if (!IsZr(fR))
	{
		if (fR < fREqFlc) //Contact
		{
			fFx = fCntctFctr * fRx * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
			fFy = fCntctFctr * fRy * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
			fFz = fCntctFctr * fRz * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
		}
		else if (fREqFlc < fR) //Attractive
		{
			fFx = fAfntyFctr * fRx * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
			fFy = fAfntyFctr * fRy * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
			fFz = fAfntyFctr * fRz * 4.0 * m_fU0 * (fCf - 1.0) * fCf * m_fRou / fREqSqr;
		}
		else //fR==fREq
		{
			fFx = 0.0;
			fFy = 0.0;
			fFz = 0.0;
		}
	}
	/////Variable finish
	/////Normal end
	return true;
}

//Itrt_Brwn, in Run(), Bi(n+1) = ∫ξ(t)dt/C  / (1 - ∂Fi(A(n+1),t)/∂Xi*△t/C ) = sqrt(2DC^2dt)*Random(N(0,1)) / (1 - ∂Fi(A(n+1),t)/∂Xi*△t/C )
//aBNxt is a small random value compared to aANxt, aANxt+aBNxt= XNxt
bool Itrt_Brwn(vector<double>& aANxt, double& fX, const double& fH, vector<double>& aBNxt)
{
	//////Safe
	//////Varialbe define
	vector<double> aCfB(aANxt.size()); //Bi(n+1)'s coef:  (1 - ∂Fi(A(n+1),t)/∂Xi*△t/C ),
	for (int i = 0; i < aBNxt.size(); ++i)
	{
		aBNxt[i] = 0.0;
		aCfB[i] = 0.0;
	}
	int iSubHAmnt = 1;
	double fSubH = fH / ((double)iSubHAmnt); 
	double fD = 0.16; // D = 0.16 [um*um/s] = 1.6e-13[m * m / s] [Modeling cell rheology with the Subcellular Element Model]
	double fCf = sqrt(2.0 * fD * fSubH); //sqrt(2*D*h), ∫ξ(t)dt/C = sqrt(2Ddt)*Random(N(0,1))
	vector<CSCE>& aSCE = *(CEmbry::GtSCEAry());
	int iSCEAmnt = aSCE.size(); //(aY.Amnt()) / 3;
	double fSrchRads = 2.0 * CSCE::REq(); //Kd Tree search radius
	double fEmbryRds = 0.5 * CEmbry::Dmtr_AdHld(fX); //Blastocyst diameter
	//////Process

	for (long iS = 0; iS < iSCEAmnt; ++iS)
	{
		for (int iSub = 0; iSub < iSubHAmnt; ++iSub)
		{
			aBNxt[iS * 3 + 0] += fCf * CSCE::GsnDstrbt()(CSCE::RndmEngn());
			aBNxt[iS * 3 + 1] += fCf * CSCE::GsnDstrbt()(CSCE::RndmEngn());
			aBNxt[iS * 3 + 2] += fCf * CSCE::GsnDstrbt()(CSCE::RndmEngn());
		}
	}

	//////Variable Finish
	//////Normal End
	return true;
}