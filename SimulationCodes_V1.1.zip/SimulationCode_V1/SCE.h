﻿#ifndef SCE_20221015
#define SCE_20221015

#include <vector>
#include <random>
#include <pcl\point_cloud.h>
#include <pcl\kdtree\kdtree_flann.h>

using std::vector;

class CSCE //Sub-cellular element
{
	//////Static
public:
	//Initial Morse potential parameters. fClDmtr is Cell Diameter, iSCEAmntInCl is the SCE amount per Cell
	static bool IntlMrsPtntlPrm(const double& fClDmtr, const int& iSCEAmntInCl);
	//Initial Pcl KdTree,
	static bool IntlPclKdTr(vector<CSCE>& aSCE);
	//Run. Calculate all SCE.m_cP/V according to initial value and external force by iterate
	//CX'(t) = F(X,t) + ξ(t) 
	//Let X(t) = A(t)+B(t), X'(t) = A'(t)+B'(t) = F(A+B,t)/C + ξ(t)/C
	//Let A'= F(A,t)/C, calculated with Order 4 Runge-Kutta
	//B' = (F(A+B,t)-F(A,t))/C + ξ(t)/C = [ ∂F(A,t)/∂X * B + O(B) ]/C + ξ(t)/C
	//Bi' = [∑∂Fi(A,t)/∂Xj * Bj +  O(B) ]/C +  ξi(t)/C
	// => Bi(n+1) - Bi(n) = [∂Fi(A(n+1),t)/∂Xi * Bi(n+1) + ∂Fi(A(n),t)/∂Xi * Bi(n)) + ∑∂Fi(A,t)/∂Xj * Bj(n) ]*△t/C + ∫ξ(t)dt/C 
	//At every step, Let A(n) = X(n), B(n) = 0 => Bi(n+1) = ∫ξ(t)dt/C  / (1 - ∂Fi(A(n+1),t)/∂Xi*△t/C ) = sqrt(2Ddt)*Random(N(0,1)) / (1 - ∂Fi(A(n+1),t)/∂Xi*△t/C ) 
	static bool Run(vector<CSCE>& aSCE, const double& fDt);
	//SCE Interaction force, calculate the force of PA to PB
	//V(R) = U0 * [( exp(ρ(1-R^2/Req^2))-1 )^2 -1], =>
	//F = - dV/dR = U0 * 4*ρ*[ exp(ρ(1-R^2/Req^2))-1 ] * exp(ρ(1-R^2/Req^2)) * ( R/Req^2 ),
	//F(P,PNr) = U0 * 4*ρ*[ exp(ρ(1-R^2/Req^2))-1 ] * exp(ρ(1-R^2/Req^2)) * (P-PNr)/Req^2
	//R^2 = Rx^2 + Ry^2 + Rz^2
	//Fx = -∂V/∂Rx = U0 * 4*ρ*[ exp(ρ(1-R^2/Req^2))-1 ] * exp(ρ(1-R^2/Req^2)) * ( Rx/Req^2 ) //Fy & Fz similar
	//Fx(Px,PNrx) = U0 * 4*ρ*[ exp(ρ(1-R^2/Req^2))-1 ] * exp(ρ(1-R^2/Req^2)) * (Px-PNrx)/Req^2 
	//Let CF = exp(ρ(1-R^2/Req^2)) = exp(ρ(1 - Rx^2/Req^2 - Ry^2/Req^2 - Rz^2/Req^2) = exp(ρ(1 - (Rx^2+Ry^2+Rz^2-PNrx^2-PNry^2-PNrz^2)/Req^2))
	static bool Intrct(double& fFx, double& fFy, double& fFz, double& fPAx, double& fPAy, double& fPAz, double& fPBx, double& fPBy, double& fPBz, const double& fCntctFctr, const double& fAfntyFctr);
	//Change fREq version
	static bool Intrct(double& fFx, double& fFy, double& fFz, double& fPAx, double& fPAy, double& fPAz, double& fPBx, double& fPBy, double& fPBz, const double& fCntctFctr, const double& fAfntyFctr, const double& fREqFlc);
	
	//Access m_cT
	static vector<double>& aT() { return m_aT; }
	//Access m_pCld
	static pcl::PointCloud<pcl::PointXYZ>::Ptr& pCld() { return m_pCld; }
	//Access m_KdTr
	static pcl::KdTreeFLANN<pcl::PointXYZ>& KdTr() { return m_KdTr; }
	//Access m_fREq
	static double& REq(void) { return m_fREq; }
	//Access m_fRou
	static double& Rou(void) { return m_fRou; }
	//Access m_fU0
	static double& U0(void) { return m_fU0; }
	//Access m_fK
	static double& K(void) { return m_fK; }
	//Access m_fCntctFctr
	static double& CntctFctr(void) { return m_fCntctFctr; }
	//Access m_fAfntyFctr_In
	static double& AfntyFctr_Intr(void) { return m_fAfntyFctr_Intr; }
	//Access m_fAfntyFctr_00
	static double& AfntyFctr_00(void) { return m_fAfntyFctr_00; }
	//Access m_fAfntyFctr_01
	static double& AfntyFctr_01(void) { return m_fAfntyFctr_01; }
	//Access m_fAfntyFctr_11
	static double& AfntyFctr_11(void) { return m_fAfntyFctr_11; }
	//Access m_fAfntyFctr_0B
	static double& AfntyFctr_0B(void) { return m_fAfntyFctr_0B; }
	//Access m_fAfntyFctr_1B
	static double& AfntyFctr_1B(void) { return m_fAfntyFctr_1B; }
	//Access m_RndmEngn
	static std::default_random_engine& RndmEngn() { return m_RndmEngn; }
	//Access m_GsnDstrbt
	static std::normal_distribution<double> GsnDstrbt() { return m_GsnDstrbt; }

private:
	static vector<double> m_aT; ///m_cT[i] =  the time of i's frame, only the frames in m_aT will be saved.
	//PCL point cloud and KD Tree
	static pcl::PointCloud<pcl::PointXYZ>::Ptr m_pCld;
	static pcl::KdTreeFLANN<pcl::PointXYZ> m_KdTr;
	//Morse potential parameters, [Modeling cell rheology with the Subcellular Element Model]
	static double m_fREq; //Equilibrium distance between SCEs, REq in literature
	static double m_fRou; //ρ,
	static double m_fU0; //Depth of potential well
	static double m_fK; //stifness
	static double m_fCntctFctr; //contact factor
	static double m_fAfntyFctr_Intr; //attractive factor, Intra-cell
	static double m_fAfntyFctr_00; //attractive factor, inter-Cell, Type0-0
	static double m_fAfntyFctr_01; //attractive factor, inter-Cell, Type0-1 & 1-2
	static double m_fAfntyFctr_11; //attractive factor, inter-Cell, Type1-1
	static double m_fAfntyFctr_0B; //attractive factor, Cell Type0 - TE
	static double m_fAfntyFctr_1B; //attractive factor, Cell Type1 - TE
	//Random variables
	static std::default_random_engine m_RndmEngn; //Random engine of C++
	static std::normal_distribution<double> m_GsnDstrbt; //Gaussian distribution
	static std::uniform_real_distribution<double> m_UnfrmDstrbt; //uniform distribution

//////non Static
public:
	//Construction
	CSCE() {;}
	//Construction of a SCE with damping, Cell ID, Type(EPI or PrE), initial location and velocity
	CSCE(const double& fC, const long& iCl, const int& iTyp, const double& fP0_x, const double& fP0_y, const double& fP0_z, const double& fV0_x, const double& fV0_y, const double& fV0_z);
	//Destruction
	~CSCE(){;}
	//Access m_fC
	double& C() { return m_fC; }
	//Access m_iCl
	long& Cl() { return m_iCl; }
	//Access m_iTyp
	int& Typ() { return m_iTyp; }
	//Access m_fPhs
	double& Phs() { return m_fPhs; }
	//Access m_aP
	vector<vector<double>>& aP() { return m_aP; }
	//Access m_aV
	vector<vector<double>>& aV() { return m_aV; }

private:
	/////
	double m_fC; //Damping coaf., 
	long m_iCl; //Cell ID, used to distinguish intra- or inter- cell interaction
	int m_iTyp; //Type. PrE or EPI
	double m_fPhs; //Phase of surface fluctuation
	vector<vector<double>> m_aP; //m_aP[t] = SCE coordinate[um]
	vector<vector<double>> m_aV; //m_aV[t] = SCE velocity[um/s]

};

//IsZero
bool IsZr(const double& fDt);
//Itrt_RK, Order 4 Runge-Kutta
//Y'=F(Y,x), Y', Y, F is vectors, x is fT
//YNxt = Y + (K1 + 2K2 + 2K3 + K4)*h/6
//K1 = F(Y,x); K2 = F(Y+0.5hK1, x+0.5h); K3 = F(Y+0.5hK2, x+0.5h), K4 = F(Y+hK3, x+h)
bool Itrt_RK(vector<double>& aY, double& fX, const double& fH, bool (*pF)(vector<double>& aF, vector<double>& aY, double fX), vector<double>& aYNxt);
//F. The F() in Itrt_RK()
bool F(vector<double>& aF, vector<double>& aY, double fX);
//Itrt_Brwn, in Run(), Bi(n+1) = ∫ξ(t)dt/C  / (1 - ∂Fi(A(n+1),t)/∂Xi*△t/C ) = sqrt(2DC^2dt)*Random(N(0,1)) / (1 - ∂Fi(A(n+1),t)/∂Xi*△t/C )
//aBNxt is a small random value compared to aANxt, aANxt+aBNxt= XNxt
bool Itrt_Brwn(vector<double>& aANxt, double& fX, const double& fH, vector<double>& aBNxt);

#endif
